-- MariaDB dump 10.19  Distrib 10.6.14-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u290874471_db_invenarios
-- ------------------------------------------------------
-- Server version	10.6.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `estado_inventario`
--

DROP TABLE IF EXISTS `estado_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_inventario` (
  `id_estado` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `comentario` varchar(200) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_inventario`
--

/*!40000 ALTER TABLE `estado_inventario` DISABLE KEYS */;
INSERT INTO `estado_inventario` VALUES (1,'Registrado','Cuando se crea la transferencia',1),(2,'En Proceso','Cuando se comienza a registrar Productos',1),(3,'Finalizada','Cuando terminan las operaciones sobre ella',1),(4,'Anulada','Anulación del Proceso',1);
/*!40000 ALTER TABLE `estado_inventario` ENABLE KEYS */;

--
-- Table structure for table `impuesto`
--

DROP TABLE IF EXISTS `impuesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impuesto` (
  `id_impuesto` int(11) NOT NULL AUTO_INCREMENT,
  `valor` int(11) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_impuesto`),
  UNIQUE KEY `uniq_prd_impuesto` (`valor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impuesto`
--

/*!40000 ALTER TABLE `impuesto` DISABLE KEYS */;
INSERT INTO `impuesto` VALUES (1,19,1);
/*!40000 ALTER TABLE `impuesto` ENABLE KEYS */;

--
-- Table structure for table `inventario_producto`
--

DROP TABLE IF EXISTS `inventario_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario_producto` (
  `id_producto` int(11) NOT NULL,
  `id_zona` int(11) NOT NULL,
  `inv_disponible` int(11) NOT NULL DEFAULT 0,
  `inv_reserva` int(11) NOT NULL DEFAULT 0,
  `int_venta_confirmada` int(11) NOT NULL DEFAULT 0,
  `inv_averias` int(11) NOT NULL DEFAULT 0,
  `inv_devoluciones` int(11) NOT NULL DEFAULT 0,
  `fecha_ultima_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_producto`,`id_zona`),
  KEY `IXFK_inventario_producto_producto` (`id_producto`),
  KEY `IXFK_inventario_producto_zona` (`id_zona`),
  CONSTRAINT `FK_inventario_producto_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_inventario_producto_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_producto`
--

/*!40000 ALTER TABLE `inventario_producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_producto` ENABLE KEYS */;

--
-- Table structure for table `inventario_producto_anio`
--

DROP TABLE IF EXISTS `inventario_producto_anio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario_producto_anio` (
  `id_producto` int(11) NOT NULL,
  `id_zona` int(11) NOT NULL,
  `anio` int(11) NOT NULL,
  `inv_disponible` int(11) NOT NULL DEFAULT 0,
  `inv_reserva` int(11) NOT NULL DEFAULT 0,
  `inv_venta_confirmada` int(11) NOT NULL DEFAULT 0,
  `inv_averias` int(11) NOT NULL DEFAULT 0,
  `inv_devoluciones` int(11) NOT NULL DEFAULT 0,
  `fecha_proceso` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_producto`,`id_zona`,`anio`),
  KEY `IXFK_inventario_producto_anio_producto` (`id_producto`),
  KEY `IXFK_inventario_producto_anio_zona` (`id_zona`),
  CONSTRAINT `FK_inventario_producto_anio_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_inventario_producto_anio_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_producto_anio`
--

/*!40000 ALTER TABLE `inventario_producto_anio` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_producto_anio` ENABLE KEYS */;

--
-- Table structure for table `inventario_producto_mes`
--

DROP TABLE IF EXISTS `inventario_producto_mes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario_producto_mes` (
  `id_producto` int(11) NOT NULL,
  `anio` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `id_zona` int(11) DEFAULT NULL,
  `inv_disponible` int(11) NOT NULL DEFAULT 0,
  `inv_reserva` int(11) NOT NULL DEFAULT 0,
  `inv_venta_confirmada` int(11) NOT NULL DEFAULT 0,
  `inv_averias` int(11) NOT NULL DEFAULT 0,
  `inv_devoluciones` int(11) NOT NULL DEFAULT 0,
  `fecha_proceso` datetime DEFAULT NULL,
  `procesado` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_producto`,`anio`,`mes`),
  KEY `IXFK_inventario_prd_mes_zona` (`id_zona`),
  KEY `IXFK_inventario_mes_prd_zona` (`id_producto`),
  CONSTRAINT `FK_inventario_prd_mes_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_inventario_prd_mes_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_producto_mes`
--

/*!40000 ALTER TABLE `inventario_producto_mes` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_producto_mes` ENABLE KEYS */;

--
-- Table structure for table `inventario_producto_semana`
--

DROP TABLE IF EXISTS `inventario_producto_semana`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario_producto_semana` (
  `id_producto` int(11) NOT NULL,
  `id_zona` int(11) NOT NULL,
  `anio` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `semana` int(11) NOT NULL,
  `inv_disponible` int(11) NOT NULL DEFAULT 0,
  `inv_reserva` int(11) NOT NULL DEFAULT 0,
  `inv_venta_confirmada` int(11) NOT NULL DEFAULT 0,
  `inv_averias` int(11) NOT NULL DEFAULT 0,
  `inv_devoluciones` int(11) NOT NULL DEFAULT 0,
  `fecha_proceso` datetime DEFAULT NULL,
  `procesado` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_producto`,`id_zona`,`anio`,`mes`,`semana`),
  KEY `IXFK_inventario_producto_semana_producto` (`id_producto`),
  KEY `IXFK_inventario_producto_semana_zona` (`id_zona`),
  CONSTRAINT `FK_inventario_producto_semana_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_inventario_producto_semana_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_producto_semana`
--

/*!40000 ALTER TABLE `inventario_producto_semana` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_producto_semana` ENABLE KEYS */;

--
-- Table structure for table `moneda`
--

DROP TABLE IF EXISTS `moneda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moneda` (
  `id_moneda` int(11) NOT NULL AUTO_INCREMENT,
  `simbolo` varchar(3) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_moneda`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moneda`
--

/*!40000 ALTER TABLE `moneda` DISABLE KEYS */;
INSERT INTO `moneda` VALUES (1,'$','COP',1),(2,'$','USD',1),(3,'$','CNY',1);
/*!40000 ALTER TABLE `moneda` ENABLE KEYS */;

--
-- Table structure for table `precio_producto`
--

DROP TABLE IF EXISTS `precio_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `precio_producto` (
  `id_producto` int(11) NOT NULL,
  `id_sucursal` int(11) NOT NULL DEFAULT -1,
  `rango_inicial` int(11) NOT NULL,
  `rango_final` int(11) NOT NULL,
  `precio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_producto`,`rango_inicial`,`id_sucursal`),
  KEY `IXFK_precio_producto_producto` (`id_producto`),
  KEY `IXFK_precio_producto_sucursal` (`id_sucursal`),
  CONSTRAINT `FK_precio_producto_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_precio_producto_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id_sucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `precio_producto`
--

/*!40000 ALTER TABLE `precio_producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `precio_producto` ENABLE KEYS */;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(50) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `codigo_barras` varchar(50) NOT NULL,
  `costo` int(11) NOT NULL DEFAULT 0,
  `precio` int(11) NOT NULL DEFAULT 0,
  `unidad_empaque` int(11) NOT NULL DEFAULT 1,
  `id_unidad_medida` int(11) NOT NULL,
  `id_tipo_producto` int(11) NOT NULL,
  `id_impuesto` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `id_subcategoria` int(11) DEFAULT NULL,
  `subcategoria` varchar(100) DEFAULT NULL,
  `stock_minimo` int(11) NOT NULL DEFAULT 50,
  `url_imagen` varchar(50) DEFAULT NULL,
  `referencia_imagen` varchar(250) NOT NULL DEFAULT '',
  `precio_rango` int(11) NOT NULL DEFAULT 1,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  UNIQUE KEY `uniq_cod_barras` (`codigo_barras`),
  KEY `IXFK_producto_impuesto` (`id_impuesto`),
  KEY `IXFK_producto_proveedor` (`id_proveedor`),
  KEY `IXFK_producto_tbl_tipo_producto` (`id_tipo_producto`),
  KEY `IXFK_producto_unidad_medida` (`id_unidad_medida`),
  KEY `IX_PRD_Ref_Producto` (`referencia`),
  KEY `IX_PRD_Precio` (`precio`),
  KEY `ix_prd_categoria` (`id_categoria`),
  KEY `ix_prd_subcateg` (`id_subcategoria`),
  CONSTRAINT `FK_producto_impuesto` FOREIGN KEY (`id_impuesto`) REFERENCES `impuesto` (`id_impuesto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_producto_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_producto_tbl_tipo_producto` FOREIGN KEY (`id_tipo_producto`) REFERENCES `tipo_producto` (`id_tipo_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_producto_unidad_medida` FOREIGN KEY (`id_unidad_medida`) REFERENCES `unidad_medida` (`id_unidad_medida`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;

--
-- Table structure for table `producto_galeria`
--

DROP TABLE IF EXISTS `producto_galeria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto_galeria` (
  `id_producto` int(11) NOT NULL,
  `posicion` int(11) NOT NULL,
  `referencia_imagen` varchar(50) DEFAULT NULL,
  `url_imagen` varchar(300) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_producto`,`posicion`),
  KEY `IXFK_producto_galeria_producto` (`id_producto`),
  CONSTRAINT `FK_producto_galeria_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_galeria`
--

/*!40000 ALTER TABLE `producto_galeria` DISABLE KEYS */;
/*!40000 ALTER TABLE `producto_galeria` ENABLE KEYS */;

--
-- Table structure for table `producto_zona`
--

DROP TABLE IF EXISTS `producto_zona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto_zona` (
  `id_producto` int(11) NOT NULL,
  `id_zona` int(11) NOT NULL,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_producto`,`id_zona`),
  KEY `IXFK_producto_zona_producto` (`id_producto`),
  KEY `IXFK_producto_zona_zona` (`id_zona`),
  CONSTRAINT `FK_producto_zona_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_producto_zona_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_zona`
--

/*!40000 ALTER TABLE `producto_zona` DISABLE KEYS */;
/*!40000 ALTER TABLE `producto_zona` ENABLE KEYS */;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `nit_proveedor` varchar(50) NOT NULL,
  `digito_verificacion` varchar(1) DEFAULT NULL,
  `id_ciudad` varchar(50) DEFAULT NULL,
  `ciudad` varchar(250) DEFAULT NULL,
  `id_departamento` varchar(50) DEFAULT NULL,
  `departamento` varchar(200) DEFAULT NULL,
  `direccion` varchar(300) DEFAULT NULL,
  `contacto` varchar(300) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nacional` int(11) NOT NULL DEFAULT 1,
  `id_moneda` int(11) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`),
  UNIQUE KEY `uniq_nomb_proveedor` (`nombre`),
  UNIQUE KEY `uniq_nit_proveedor` (`nit_proveedor`,`digito_verificacion`),
  KEY `IXFK_proveedor_moneda` (`id_moneda`),
  CONSTRAINT `FK_proveedor_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `moneda` (`id_moneda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;

--
-- Table structure for table `sector_sucursal`
--

DROP TABLE IF EXISTS `sector_sucursal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sector_sucursal` (
  `id_sector` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `referencia` varchar(50) NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sector`),
  UNIQUE KEY `uniq_ref_sector_bodega` (`referencia`),
  KEY `IXFK_sector_sucursal_sucursal` (`id_sucursal`),
  CONSTRAINT `FK_sector_sucursal_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id_sucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector_sucursal`
--

/*!40000 ALTER TABLE `sector_sucursal` DISABLE KEYS */;
INSERT INTO `sector_sucursal` VALUES (1,'Sector App','Sector App','sapp',2,1,'DEVELOPER','2023-07-17 20:07:30',NULL,NULL);
/*!40000 ALTER TABLE `sector_sucursal` ENABLE KEYS */;

--
-- Table structure for table `sucursal`
--

DROP TABLE IF EXISTS `sucursal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursal` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `id_ciudad` varchar(50) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `id_departamento` varchar(50) DEFAULT NULL,
  `departamento` varchar(200) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefonos` varchar(100) DEFAULT NULL,
  `tipo` varchar(1) DEFAULT NULL COMMENT 'Tienda - Bodega - Centro Distribucion',
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`),
  UNIQUE KEY `uniq_suc_nombre` (`nombre`),
  CONSTRAINT `ch_tipo_sucursal` CHECK (`tipo` in ('T','B','C'))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursal`
--

/*!40000 ALTER TABLE `sucursal` DISABLE KEYS */;
INSERT INTO `sucursal` VALUES (1,'web','11001','Bogotá D.C.','11','Bogotá D.C.','pagina web','Frank Leon','kagure@gmail.com','3013273733','T',1,'DEVELOPER','2023-07-17 20:04:43',NULL,NULL),(2,'app','11001','Bogotá D.C.','11','Bogotá D.C.','app','Frank Toro','kagure@gmail.com','3013273733','T',1,'DEVELOPER','2023-07-17 20:06:44',NULL,NULL);
/*!40000 ALTER TABLE `sucursal` ENABLE KEYS */;

--
-- Table structure for table `tipo_inventario`
--

DROP TABLE IF EXISTS `tipo_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_inventario` (
  `id_tipo_inventario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_inventario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_inventario`
--

/*!40000 ALTER TABLE `tipo_inventario` DISABLE KEYS */;
INSERT INTO `tipo_inventario` VALUES (1,'Disponible','Inventario Disponible para la venta'),(2,'Reserva','Inventario Reservado'),(3,'Venta','Inventario Vendido'),(4,'Devolución','Inventario Devuelto Posterior a la Venta'),(5,'Averias','Inventario Dañado');
/*!40000 ALTER TABLE `tipo_inventario` ENABLE KEYS */;

--
-- Table structure for table `tipo_producto`
--

DROP TABLE IF EXISTS `tipo_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_producto` (
  `id_tipo_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tipo_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_producto`
--

/*!40000 ALTER TABLE `tipo_producto` DISABLE KEYS */;
INSERT INTO `tipo_producto` VALUES (-1,'No Aplica',0),(1,'Almacenable',1),(2,'Consumible',1),(3,'Servicio',1);
/*!40000 ALTER TABLE `tipo_producto` ENABLE KEYS */;

--
-- Table structure for table `transaccion`
--

DROP TABLE IF EXISTS `transaccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaccion` (
  `id_transaccion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `sigla` varchar(50) DEFAULT NULL,
  `id_tipo_inventario` int(11) DEFAULT NULL,
  `observacion` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_transaccion`),
  UNIQUE KEY `uniq_nomb_transaccion` (`nombre`),
  KEY `IXFK_transaccion_tipo_inventario` (`id_tipo_inventario`),
  CONSTRAINT `FK_transaccion_tipo_inventario` FOREIGN KEY (`id_tipo_inventario`) REFERENCES `tipo_inventario` (`id_tipo_inventario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaccion`
--

/*!40000 ALTER TABLE `transaccion` DISABLE KEYS */;
INSERT INTO `transaccion` VALUES (1,'Compra a Proveedor','DISPROV',1,'',1),(2,'Transferencia a Sucursal','TRFSUC',1,'Inventario que se pasa de sucursal a sucursal',1),(3,'Reserva x Pedido','RP',2,'Reserva por toma de Pedido',1),(4,'Reserva x Compra','RC',2,'Reserva de inventario que luego sera disponible',1),(5,'Venta Confirmada','VC',3,'Venta confirmada de mercancia',1),(6,'Devolución Pedido','DP',4,'Devolución de Pedido',0),(7,'Devolución x Avería','DA',4,'Devolución por producto defectuoso',1),(8,'Avería de Importación','AP',5,'Inventario que llegó malo desde el origen',1),(9,'Avería en Sitio','AS',5,'Inventario que se danio en proceso interno',1);
/*!40000 ALTER TABLE `transaccion` ENABLE KEYS */;

--
-- Table structure for table `transferencia`
--

DROP TABLE IF EXISTS `transferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transferencia` (
  `id_transferencia` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_transaccion` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `valor_referencia` varchar(50) DEFAULT NULL,
  `comentario` varchar(100) DEFAULT NULL,
  `observacion` varchar(100) DEFAULT NULL,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT '',
  `fecha_modificacion` datetime DEFAULT NULL,
  `procesado` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_transferencia`),
  KEY `IXFK_transferencia_estado_inventario` (`id_estado`),
  KEY `IXFK_transferencia_transaccion` (`id_transaccion`),
  KEY `ix_val_ref_trf` (`valor_referencia`),
  CONSTRAINT `FK_transferencia_estado_inventario` FOREIGN KEY (`id_estado`) REFERENCES `estado_inventario` (`id_estado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_transaccion` FOREIGN KEY (`id_transaccion`) REFERENCES `transaccion` (`id_transaccion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferencia`
--

/*!40000 ALTER TABLE `transferencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferencia` ENABLE KEYS */;

--
-- Table structure for table `transferencia_dtl`
--

DROP TABLE IF EXISTS `transferencia_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transferencia_dtl` (
  `id_transferencia_dtl` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_transferencia` bigint(20) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `id_sector` int(11) NOT NULL,
  `id_zona` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_transferencia_dtl_ref` bigint(20) DEFAULT -1 COMMENT 'codigo de la transferencia referencia',
  `codigo_barras` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `costo_producto` int(11) DEFAULT NULL,
  `precio_unitario` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `origen` varchar(50) NOT NULL,
  `codigo_ref_origen` varchar(50) NOT NULL DEFAULT '-1',
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `procesado` int(11) NOT NULL DEFAULT 0,
  `comentario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_dtl`),
  KEY `IXFK_transferencia_dtl_estado_inventario` (`id_estado`),
  KEY `IXFK_transferencia_dtl_producto` (`id_producto`),
  KEY `IXFK_transferencia_dtl_proveedor` (`id_proveedor`),
  KEY `IXFK_transferencia_dtl_sector_sucursal` (`id_sector`),
  KEY `IXFK_transferencia_dtl_sucursal` (`id_sucursal`),
  KEY `IXFK_transferencia_dtl_transferencia` (`id_transferencia`),
  KEY `IXFK_transferencia_dtl_zona` (`id_zona`),
  KEY `IX_TRF_DTL_id_Trf_padre` (`id_transferencia_dtl_ref`),
  CONSTRAINT `FK_transferencia_dtl_estado_inventario` FOREIGN KEY (`id_estado`) REFERENCES `estado_inventario` (`id_estado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_sector_sucursal` FOREIGN KEY (`id_sector`) REFERENCES `sector_sucursal` (`id_sector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id_sucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_transferencia` FOREIGN KEY (`id_transferencia`) REFERENCES `transferencia` (`id_transferencia`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transferencia_dtl_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id_zona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferencia_dtl`
--

/*!40000 ALTER TABLE `transferencia_dtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferencia_dtl` ENABLE KEYS */;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unidad_medida` (
  `id_unidad_medida` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) DEFAULT NULL,
  `sigla` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_unidad_medida`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES (1,'Sin Unidad Determinada','NA',1),(2,'Unidad','UNI',1),(3,'Docena','DOC',1),(4,'Bolsa','BOL',1),(5,'Kilo','KG',1),(6,'Libra','LIB',1),(7,'Bulto','BUL',1),(8,'Caja','CAJA',1),(9,'PCS','PCS',1),(10,'Metros','MTS',1),(11,'CM','CM',1),(12,'Pulgada','PUL',1),(13,'Litro','LT',1);
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;

--
-- Table structure for table `zona`
--

DROP TABLE IF EXISTS `zona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zona` (
  `id_zona` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `id_sector` int(11) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_zona`),
  UNIQUE KEY `uniq_ref_zona` (`referencia`),
  KEY `IXFK_zona_sector_sucursal` (`id_sector`),
  CONSTRAINT `FK_zona_sector_sucursal` FOREIGN KEY (`id_sector`) REFERENCES `sector_sucursal` (`id_sector`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zona`
--

/*!40000 ALTER TABLE `zona` DISABLE KEYS */;
INSERT INTO `zona` VALUES (1,'Zona App','zapp','Zona App',1,1,'DEVELOPER','2023-07-17 20:07:55',NULL,NULL);
/*!40000 ALTER TABLE `zona` ENABLE KEYS */;

--
-- Dumping routines for database 'u290874471_db_invenarios'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-27 20:08:53
