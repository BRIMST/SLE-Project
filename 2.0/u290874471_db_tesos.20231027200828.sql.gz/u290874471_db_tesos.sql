-- MariaDB dump 10.19  Distrib 10.6.14-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u290874471_db_tesos
-- ------------------------------------------------------
-- Server version	10.6.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ciudad` (
  `idCiudad` varchar(50) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `idDepartamento` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`idCiudad`),
  KEY `IXFK_ciudad_departamento` (`idDepartamento`),
  CONSTRAINT `FK_ciudad_departamento` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`idDepartamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudad`
--

/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` VALUES ('1111001','Bogotá D.C.','11',1),('1313001','Cartagena','13',1),('1313006','Achí','13',1),('131303','Altos del Rosario','13',1),('1313042','Arenal','13',1),('1313052','Arjona','13',1),('1313062','Arroyohondo','13',1),('1313074','Barranco de Loba','13',1),('131314','Calamar','13',1),('131316','Cantagallo','13',1),('1313188','Cicuco','13',1),('1313212','Córdoba','13',1),('1313222','Clemencia','13',1),('1313244','El Carmen de Bolívar','13',1),('1313248','El Guamo','13',1),('1313268','El Peñón','13',1),('13133','Hatillo de Loba','13',1),('131343','Magangué','13',1),('1313433','Mahates','13',1),('131344','Margarita','13',1),('1313442','María la Baja','13',1),('1313458','Montecristo','13',1),('1313468','Mompós','13',1),('1313473','Morales','13',1),('131349','Norosí','13',1),('1313549','Pinillos','13',1),('131358','Regidor','13',1),('13136','Río Viejo','13',1),('131362','San Cristóbal','13',1),('1313647','San Estanislao','13',1),('131365','San Fernando','13',1),('1313654','San Jacinto','13',1),('1313655','San Jacinto del Cauca','13',1),('1313657','San Juan Nepomuceno','13',1),('1313667','San Martín de Loba','13',1),('131367','San Pablo de Borbur','13',1),('1313673','Santa Catalina','13',1),('1313683','Santa Rosa','13',1),('1313688','Santa Rosa del Sur','13',1),('1313744','Simití','13',1),('131376','Soplaviento','13',1),('131378','Talaigua Nuevo','13',1),('131381','Tiquisio','13',1),('1313836','Turbaco','13',1),('1313838','Turbaná','13',1),('1313873','Villanueva','13',1),('1313894','Zambrano','13',1),('1515001','Tunja','15',1),('1515022','Almeida','15',1),('1515047','Aquitania','15',1),('1515051','Arcabuco','15',1),('1515087','Belén','15',1),('151509','Berbeo','15',1),('1515092','Betéitiva','15',1),('1515097','Boavita','15',1),('1515104','Boyacá','15',1),('1515106','Briceño','15',1),('1515109','Buena Vista','15',1),('1515114','Busbanzá','15',1),('1515131','Caldas','15',1),('1515135','Campohermoso','15',1),('1515162','Cerinza','15',1),('1515172','Chinavita','15',1),('1515176','Chiquinquirá','15',1),('151518','Chiscas','15',1),('1515183','Chita','15',1),('1515185','Chitaraque','15',1),('1515187','Chivatá','15',1),('1515189','Ciénega','15',1),('1515204','Cómbita','15',1),('1515212','Coper','15',1),('1515215','Corrales','15',1),('1515218','Covarachía','15',1),('1515223','Cubará','15',1),('1515224','Cucaita','15',1),('1515226','Cuítiva','15',1),('1515232','Chíquiza','15',1),('1515236','Chivor','15',1),('1515238','Duitama','15',1),('1515244','El Cocuy','15',1),('1515248','El Espino','15',1),('1515272','Firavitoba','15',1),('1515276','Floresta','15',1),('1515293','Gachantivá','15',1),('1515296','Gameza','15',1),('1515299','Garagoa','15',1),('1515317','Guacamayas','15',1),('1515322','Guateque','15',1),('1515325','Guayatá','15',1),('1515332','Güicán','15',1),('1515362','Iza','15',1),('1515367','Jenesano','15',1),('1515368','Jericó','15',1),('1515377','Labranzagrande','15',1),('151538','La Capilla','15',1),('1515401','La Victoria','15',1),('1515403','La Uvita','15',1),('1515407','Villa de Leyva','15',1),('1515425','Macanal','15',1),('1515442','Maripí','15',1),('1515455','Miraflores','15',1),('1515464','Mongua','15',1),('1515466','Monguí','15',1),('1515469','Moniquirá','15',1),('1515476','Motavita','15',1),('151548','Muzo','15',1),('1515491','Nobsa','15',1),('1515494','Nuevo Colón','15',1),('15155','Oicatá','15',1),('1515507','Otanche','15',1),('1515511','Pachavita','15',1),('1515514','Páez','15',1),('1515516','Paipa','15',1),('1515518','Pajarito','15',1),('1515522','Panqueba','15',1),('1515531','Pauna','15',1),('1515533','Paya','15',1),('1515537','Paz de Río','15',1),('1515542','Pesca','15',1),('151555','Pisba','15',1),('1515572','Puerto Boyacá','15',1),('151558','Quípama','15',1),('1515599','Ramiriquí','15',1),('15156','Ráquira','15',1),('1515621','Rondón','15',1),('1515632','Saboyá','15',1),('1515638','Sáchica','15',1),('1515646','Samacá','15',1),('151566','San Eduardo','15',1),('1515664','San José de Pare','15',1),('1515667','San Luis de Gaceno','15',1),('1515673','San Mateo','15',1),('1515676','San Miguel de Sema','15',1),('1515681','San Pablo de Borbur','15',1),('1515686','Santana','15',1),('151569','Santa María','15',1),('1515693','Santa Rosa de Viterbo','15',1),('1515696','Santa Sofía','15',1),('151572','Sativanorte','15',1),('1515723','Sativasur','15',1),('151574','Siachoque','15',1),('1515753','Soatá','15',1),('1515755','Socotá','15',1),('1515757','Socha','15',1),('1515759','Sogamoso','15',1),('1515761','Somondoco','15',1),('1515762','Sora','15',1),('1515763','Sotaquirá','15',1),('1515764','Soracá','15',1),('1515774','Susacón','15',1),('1515776','Sutamarchán','15',1),('1515778','Sutatenza','15',1),('151579','Tasco','15',1),('1515798','Tenza','15',1),('1515804','Tibaná','15',1),('1515806','Tibasosa','15',1),('1515808','Tinjacá','15',1),('151581','Tipacoque','15',1),('1515814','Toca','15',1),('1515816','Togüí','15',1),('151582','Tópaga','15',1),('1515822','Tota','15',1),('1515832','Tununguá','15',1),('1515835','Turmequé','15',1),('1515837','Tuta','15',1),('1515839','Tutazá','15',1),('1515842','Umbita','15',1),('1515861','Ventaquemada','15',1),('1515879','Viracachá','15',1),('1515897','Zetaquira','15',1),('1717001','Manizales','17',1),('1717013','Aguadas','17',1),('1717042','Anserma','17',1),('171705','Aranzazu','17',1),('1717088','Belalcázar','17',1),('1717174','Chinchiná','17',1),('1717272','Filadelfia','17',1),('171738','La Dorada','17',1),('1717388','La Merced','17',1),('1717433','Manzanares','17',1),('1717442','Marmato','17',1),('1717444','Marquetalia','17',1),('1717446','Marulanda','17',1),('1717486','Neira','17',1),('1717495','Norcasia','17',1),('1717513','Pácora','17',1),('1717524','Palestina','17',1),('1717541','Pensilvania','17',1),('1717614','Riosucio','17',1),('1717616','Risaralda','17',1),('1717653','Salamina','17',1),('1717662','Samaná','17',1),('1717665','San José','17',1),('1717777','Supía','17',1),('1717867','Victoria','17',1),('1717873','Villamaría','17',1),('1717877','Viterbo','17',1),('1818001','Florencia','18',1),('1818029','Albania','18',1),('1818094','Belén de Los Andaquies','18',1),('181815','Cartagena del Chairá','18',1),('1818205','Curillo','18',1),('1818247','El Doncello','18',1),('1818256','El Paujil','18',1),('181841','La Montañita','18',1),('181846','Milán','18',1),('1818479','Morelia','18',1),('1818592','Puerto Rico','18',1),('181861','San José del Fragua','18',1),('1818753','San Vicente del Caguán','18',1),('1818756','Solano','18',1),('1818785','Solita','18',1),('181886','Valparaíso','18',1),('1919001','Popayán','19',1),('1919022','Almaguer','19',1),('191905','Argelia','19',1),('1919075','Balboa','19',1),('19191','Bolívar','19',1),('191911','Buenos Aires','19',1),('191913','Cajibío','19',1),('1919137','Caldono','19',1),('1919142','Caloto','19',1),('1919212','Corinto','19',1),('1919256','El Tambo','19',1),('191929','Florencia','19',1),('19193','Guachené','19',1),('1919318','Guapi','19',1),('1919355','Inzá','19',1),('1919364','Jambaló','19',1),('1919392','La Sierra','19',1),('1919397','La Vega','19',1),('1919418','López','19',1),('191945','Mercaderes','19',1),('1919455','Miranda','19',1),('1919473','Morales','19',1),('1919513','Padilla','19',1),('1919517','Páez','19',1),('1919532','Patía','19',1),('1919533','Piamonte','19',1),('1919548','Piendamó','19',1),('1919573','Puerto Tejada','19',1),('1919585','Puracé','19',1),('1919622','Rosas','19',1),('1919693','San Sebastián','19',1),('1919698','Santander de Quilichao','19',1),('1919701','Santa Rosa','19',1),('1919743','Silvia','19',1),('191976','Sotara','19',1),('191978','Suárez','19',1),('1919785','Sucre','19',1),('1919807','Timbío','19',1),('1919809','Timbiquí','19',1),('1919821','Toribio','19',1),('1919824','Totoró','19',1),('1919845','Villa Rica','19',1),('2020001','Valledupar','20',1),('2020011','Aguachica','20',1),('2020013','Agustín Codazzi','20',1),('2020032','Astrea','20',1),('2020045','Becerril','20',1),('202006','Bosconia','20',1),('2020175','Chimichagua','20',1),('2020178','Chiriguaná','20',1),('2020228','Curumaní','20',1),('2020238','El Copey','20',1),('202025','El Paso','20',1),('2020295','Gamarra','20',1),('202031','González','20',1),('2020383','La Gloria','20',1),('20204','La Jagua de Ibirico','20',1),('2020443','Manaure','20',1),('2020517','Pailitas','20',1),('202055','Pelaya','20',1),('202057','Pueblo Bello','20',1),('2020614','Río de Oro','20',1),('2020621','La Paz','20',1),('202071','San Alberto','20',1),('202075','San Diego','20',1),('202077','San Martín','20',1),('2020787','Tamalameque','20',1),('2323001','Montería','23',1),('2323068','Ayapel','23',1),('2323079','Buenavista','23',1),('232309','Canalete','23',1),('2323162','Cereté','23',1),('2323168','Chimá','23',1),('2323182','Chinú','23',1),('2323189','Ciénaga de Oro','23',1),('23233','Cotorra','23',1),('232335','La Apartada','23',1),('2323417','Lorica','23',1),('2323419','Los Córdobas','23',1),('2323464','Momil','23',1),('2323466','Montelíbano','23',1),('23235','Moñitos','23',1),('2323555','Planeta Rica','23',1),('232357','Pueblo Nuevo','23',1),('2323574','Puerto Escondido','23',1),('232358','Puerto Libertador','23',1),('2323586','Purísima','23',1),('232366','Sahagún','23',1),('232367','San Andrés Sotavento','23',1),('2323672','San Antero','23',1),('2323675','San Bernardo del Viento','23',1),('2323678','San Carlos','23',1),('2323682','San José de Uré','23',1),('2323686','San Pelayo','23',1),('2323807','Tierralta','23',1),('2323815','Tuchín','23',1),('2323855','Valencia','23',1),('2525001','Agua de Dios','25',1),('2525019','Albán','25',1),('2525035','Anapoima','25',1),('252504','Anolaima','25',1),('2525053','Arbeláez','25',1),('2525086','Beltrán','25',1),('2525095','Bituima','25',1),('2525099','Bojacá','25',1),('252512','Cabrera','25',1),('2525123','Cachipay','25',1),('2525126','Cajicá','25',1),('2525148','Caparrapí','25',1),('2525151','Caqueza','25',1),('2525154','Carmen de Carupa','25',1),('2525168','Chaguaní','25',1),('2525175','Chía','25',1),('2525178','Chipaque','25',1),('2525181','Choachí','25',1),('2525183','Chocontá','25',1),('25252','Cogua','25',1),('2525214','Cota','25',1),('2525224','Cucunubá','25',1),('2525245','El Colegio','25',1),('2525258','El Peñón','25',1),('252526','El Rosal','25',1),('2525269','Facatativá','25',1),('2525279','Fomeque','25',1),('2525281','Fosca','25',1),('2525286','Funza','25',1),('2525288','Fúquene','25',1),('252529','Fusagasugá','25',1),('2525293','Gachala','25',1),('2525295','Gachancipá','25',1),('2525297','Gachetá','25',1),('2525299','Gama','25',1),('2525307','Girardot','25',1),('2525312','Granada','25',1),('2525317','Guachetá','25',1),('252532','Guaduas','25',1),('2525322','Guasca','25',1),('2525324','Guataquí','25',1),('2525326','Guatavita','25',1),('2525328','Guayabal de Siquima','25',1),('2525335','Guayabetal','25',1),('2525339','Gutiérrez','25',1),('2525368','Jerusalén','25',1),('2525372','Junín','25',1),('2525377','La Calera','25',1),('2525386','La Mesa','25',1),('2525394','La Palma','25',1),('2525398','La Peña','25',1),('2525402','La Vega','25',1),('2525407','Lenguazaque','25',1),('2525426','Macheta','25',1),('252543','Madrid','25',1),('2525436','Manta','25',1),('2525438','Medina','25',1),('2525473','Mosquera','25',1),('2525483','Nariño','25',1),('2525486','Nemocón','25',1),('2525488','Nilo','25',1),('2525489','Nimaima','25',1),('2525491','Nocaima','25',1),('2525506','Venecia','25',1),('2525513','Pacho','25',1),('2525518','Paime','25',1),('2525524','Pandi','25',1),('252553','Paratebueno','25',1),('2525535','Pasca','25',1),('2525572','Puerto Salgar','25',1),('252558','Pulí','25',1),('2525592','Quebradanegra','25',1),('2525594','Quetame','25',1),('2525596','Quipile','25',1),('2525599','Apulo','25',1),('2525612','Ricaurte','25',1),('2525645','San Antonio del Tequendama','25',1),('2525649','San Bernardo','25',1),('2525653','San Cayetano','25',1),('2525658','San Francisco','25',1),('2525662','San Juan de Río Seco','25',1),('2525718','Sasaima','25',1),('2525736','Sesquilé','25',1),('252574','Sibaté','25',1),('2525743','Silvania','25',1),('2525745','Simijaca','25',1),('2525754','Soacha','25',1),('2525758','Sopó','25',1),('2525769','Subachoque','25',1),('2525772','Suesca','25',1),('2525777','Supatá','25',1),('2525779','Susa','25',1),('2525781','Sutatausa','25',1),('2525785','Tabio','25',1),('2525793','Tausa','25',1),('2525797','Tena','25',1),('2525799','Tenjo','25',1),('2525805','Tibacuy','25',1),('2525807','Tibirita','25',1),('2525815','Tocaima','25',1),('2525817','Tocancipá','25',1),('2525823','Topaipí','25',1),('2525839','Ubalá','25',1),('2525841','Ubaque','25',1),('2525843','Villa de San Diego de Ubate','25',1),('2525845','Une','25',1),('2525851','Útica','25',1),('2525862','Vergara','25',1),('2525867','Vianí','25',1),('2525871','Villagómez','25',1),('2525873','Villapinzón','25',1),('2525875','Villeta','25',1),('2525878','Viotá','25',1),('2525885','Yacopí','25',1),('2525898','Zipacón','25',1),('2525899','Zipaquirá','25',1),('2727001','Quibdó','27',1),('2727006','Acandí','27',1),('2727025','Alto Baudo','27',1),('272705','Atrato','27',1),('2727073','Bagadó','27',1),('2727075','Bahía Solano','27',1),('2727077','Bajo Baudó','27',1),('2727086','Belén de Bajira','27',1),('2727099','Bojaya','27',1),('2727135','El Cantón del San Pablo','27',1),('272715','Carmen del Darien','27',1),('272716','Cértegui','27',1),('2727205','Condoto','27',1),('2727245','El Carmen de Atrato','27',1),('272725','El Litoral del San Juan','27',1),('2727361','Istmina','27',1),('2727372','Juradó','27',1),('2727413','Lloró','27',1),('2727425','Medio Atrato','27',1),('272743','Medio Baudó','27',1),('272745','Medio San Juan','27',1),('2727491','Nóvita','27',1),('2727495','Nuquí','27',1),('272758','Río Iro','27',1),('27276','Río Quito','27',1),('2727615','Riosucio','27',1),('272766','San José del Palmar','27',1),('2727745','Sipí','27',1),('2727787','Tadó','27',1),('27278','Unguía','27',1),('272781','Unión Panamericana','27',1),('4141001','Neiva','41',1),('4141006','Acevedo','41',1),('4141013','Agrado','41',1),('4141016','Aipe','41',1),('414102','Algeciras','41',1),('4141026','Altamira','41',1),('4141078','Baraya','41',1),('4141132','Campoalegre','41',1),('4141206','Colombia','41',1),('4141244','Elías','41',1),('4141298','Garzón','41',1),('4141306','Gigante','41',1),('4141319','Guadalupe','41',1),('4141349','Hobo','41',1),('4141357','Iquira','41',1),('4141359','Isnos','41',1),('4141378','La Argentina','41',1),('4141396','La Plata','41',1),('4141483','Nátaga','41',1),('4141503','Oporapa','41',1),('4141518','Paicol','41',1),('4141524','Palermo','41',1),('414153','Palestina','41',1),('4141548','Pital','41',1),('4141551','Pitalito','41',1),('4141615','Rivera','41',1),('414166','Saladoblanco','41',1),('4141668','San Agustín','41',1),('4141676','Santa María','41',1),('414177','Suaza','41',1),('4141791','Tarqui','41',1),('4141797','Tesalia','41',1),('4141799','Tello','41',1),('4141801','Teruel','41',1),('4141807','Timaná','41',1),('4141872','Villavieja','41',1),('4141885','Yaguará','41',1),('4444001','Riohacha','44',1),('4444035','Albania','44',1),('4444078','Barrancas','44',1),('444409','Dibula','44',1),('4444098','Distracción','44',1),('444411','El Molino','44',1),('4444279','Fonseca','44',1),('4444378','Hatonuevo','44',1),('444442','La Jagua del Pilar','44',1),('444443','Maicao','44',1),('444456','Manaure','44',1),('444465','San Juan del Cesar','44',1),('4444847','Uribia','44',1),('4444855','Urumita','44',1),('4444874','Villanueva','44',1),('4747001','Santa Marta','47',1),('474703','Algarrobo','47',1),('4747053','Aracataca','47',1),('4747058','Ariguaní','47',1),('4747161','Cerro San Antonio','47',1),('474717','Chivolo','47',1),('4747189','Ciénaga','47',1),('4747205','Concordia','47',1),('4747245','El Banco','47',1),('4747258','El Piñon','47',1),('4747268','El Retén','47',1),('4747288','Fundación','47',1),('4747318','Guamal','47',1),('474746','Nueva Granada','47',1),('4747541','Pedraza','47',1),('4747545','Pijiño del Carmen','47',1),('4747551','Pivijay','47',1),('4747555','Plato','47',1),('474757','Pueblo Viejo','47',1),('4747605','Remolino','47',1),('474766','Sabanas de San Angel','47',1),('4747675','Salamina','47',1),('4747692','San Sebastián de Buenavista','47',1),('4747703','San Zenón','47',1),('4747707','Santa Ana','47',1),('474772','Santa Bárbara de Pinto','47',1),('4747745','Sitionuevo','47',1),('4747798','Tenerife','47',1),('474796','Zapayán','47',1),('474798','Zona Bananera','47',1),('5050001','Villavicencio','50',1),('5050006','Acacias','50',1),('505011','Barranca de Upía','50',1),('5050124','Cabuyaro','50',1),('505015','Castilla la Nueva','50',1),('5050223','Cubarral','50',1),('5050226','Cumaral','50',1),('5050245','El Calvario','50',1),('5050251','El Castillo','50',1),('505027','El Dorado','50',1),('5050287','Fuente de Oro','50',1),('5050313','Granada','50',1),('5050318','Guamal','50',1),('5050325','Mapiripán','50',1),('505033','Mesetas','50',1),('505035','La Macarena','50',1),('505037','Uribe','50',1),('50504','Lejanías','50',1),('505045','Puerto Concordia','50',1),('5050568','Puerto Gaitán','50',1),('5050573','Puerto López','50',1),('5050577','Puerto Lleras','50',1),('505059','Puerto Rico','50',1),('5050606','Restrepo','50',1),('505068','San Carlos de Guaroa','50',1),('5050683','San Juan de Arama','50',1),('5050686','San Juanito','50',1),('5050689','San Martín','50',1),('5050711','Vista Hermosa','50',1),('5252001','Pasto','52',1),('5252019','Albán','52',1),('5252022','Aldana','52',1),('5252036','Ancuyá','52',1),('5252051','Arboleda','52',1),('5252079','Barbacoas','52',1),('5252083','Belén','52',1),('525211','Buesaco','52',1),('5252203','Colón','52',1),('5252207','Consaca','52',1),('525221','Contadero','52',1),('5252215','Córdoba','52',1),('5252224','Cuaspud','52',1),('5252227','Cumbal','52',1),('5252233','Cumbitara','52',1),('525224','Chachagüí','52',1),('525225','El Charco','52',1),('5252254','El Peñol','52',1),('5252256','El Rosario','52',1),('5252258','El Tablón de Gómez','52',1),('525226','El Tambo','52',1),('5252287','Funes','52',1),('5252317','Guachucal','52',1),('525232','Guaitarilla','52',1),('5252323','Gualmatán','52',1),('5252352','Iles','52',1),('5252354','Imués','52',1),('5252356','Ipiales','52',1),('5252378','La Cruz','52',1),('5252381','La Florida','52',1),('5252385','La Llanada','52',1),('525239','La Tola','52',1),('5252399','La Unión','52',1),('5252405','Leiva','52',1),('5252411','Linares','52',1),('5252418','Los Andes','52',1),('5252427','Magüí','52',1),('5252435','Mallama','52',1),('5252473','Mosquera','52',1),('525248','Nariño','52',1),('525249','Olaya Herrera','52',1),('5252506','Ospina','52',1),('525252','Francisco Pizarro','52',1),('525254','Policarpa','52',1),('525256','Potosí','52',1),('5252565','Providencia','52',1),('5252573','Puerres','52',1),('5252585','Pupiales','52',1),('5252612','Ricaurte','52',1),('5252621','Roberto Payán','52',1),('5252678','Samaniego','52',1),('5252683','Sandoná','52',1),('5252685','San Bernardo','52',1),('5252687','San Lorenzo','52',1),('5252693','San Pablo','52',1),('5252694','San Pedro de Cartago','52',1),('5252696','Santa Bárbara','52',1),('5252699','Santacruz','52',1),('525272','Sapuyes','52',1),('5252786','Taminango','52',1),('5252788','Tangua','52',1),('5252835','San Andrés de Tumaco','52',1),('5252838','Túquerres','52',1),('5252885','Yacuanquer','52',1),('5454001','Cúcuta','54',1),('5454003','Abrego','54',1),('5454051','Arboledas','54',1),('5454099','Bochalema','54',1),('5454109','Bucarasica','54',1),('5454125','Cácota','54',1),('5454128','Cachirá','54',1),('5454172','Chinácota','54',1),('5454174','Chitagá','54',1),('5454206','Convención','54',1),('5454223','Cucutilla','54',1),('5454239','Durania','54',1),('5454245','El Carmen','54',1),('545425','El Tarra','54',1),('5454261','El Zulia','54',1),('5454313','Gramalote','54',1),('5454344','Hacarí','54',1),('5454347','Herrán','54',1),('5454377','Labateca','54',1),('5454385','La Esperanza','54',1),('5454398','La Playa','54',1),('5454405','Los Patios','54',1),('5454418','Lourdes','54',1),('545448','Mutiscua','54',1),('5454498','Ocaña','54',1),('5454518','Pamplona','54',1),('545452','Pamplonita','54',1),('5454553','Puerto Santander','54',1),('5454599','Ragonvalia','54',1),('545466','Salazar','54',1),('545467','San Calixto','54',1),('5454673','San Cayetano','54',1),('545468','Santiago','54',1),('545472','Sardinata','54',1),('5454743','Silos','54',1),('54548','Teorama','54',1),('545481','Tibú','54',1),('545482','Toledo','54',1),('5454871','Villa Caro','54',1),('5454874','Villa del Rosario','54',1),('55001','Medellín','5',1),('55002','Abejorral','5',1),('55004','Abriaquí','5',1),('55021','Alejandría','5',1),('5503','Amagá','5',1),('55031','Amalfi','5',1),('55034','Andes','5',1),('55036','Angelópolis','5',1),('55038','Angostura','5',1),('5504','Anorí','5',1),('55042','Santafé de Antioquia','5',1),('55044','Anza','5',1),('55045','Apartadó','5',1),('55051','Arboletes','5',1),('55055','Argelia','5',1),('55059','Armenia','5',1),('55079','Barbosa','5',1),('55086','Belmira','5',1),('55088','Bello','5',1),('55091','Betania','5',1),('55093','Betulia','5',1),('55101','Ciudad Bolívar','5',1),('55107','Briceño','5',1),('55113','Buriticá','5',1),('5512','Cáceres','5',1),('55125','Caicedo','5',1),('55129','Caldas','5',1),('55134','Campamento','5',1),('55138','Cañasgordas','5',1),('55142','Caracolí','5',1),('55145','Caramanta','5',1),('55147','Carepa','5',1),('55148','El Carmen de Viboral','5',1),('5515','Carolina','5',1),('55154','Caucasia','5',1),('55172','Chigorodó','5',1),('5519','Cisneros','5',1),('55197','Cocorná','5',1),('55206','Concepción','5',1),('55209','Concordia','5',1),('55212','Copacabana','5',1),('55234','Dabeiba','5',1),('55237','Don Matías','5',1),('5524','Ebéjico','5',1),('5525','El Bagre','5',1),('55264','Entrerrios','5',1),('55266','Envigado','5',1),('55282','Fredonia','5',1),('55284','Frontino','5',1),('55306','Giraldo','5',1),('55308','Girardota','5',1),('5531','Gómez Plata','5',1),('55313','Granada','5',1),('55315','Guadalupe','5',1),('55318','Guarne','5',1),('55321','Guatapé','5',1),('55347','Heliconia','5',1),('55353','Hispania','5',1),('5536','Itagui','5',1),('55361','Ituango','5',1),('55364','Jardín','5',1),('55368','Jericó','5',1),('55376','La Ceja','5',1),('5538','La Estrella','5',1),('5539','La Pintada','5',1),('554','La Unión','5',1),('55411','Liborina','5',1),('55425','Maceo','5',1),('5544','Marinilla','5',1),('55467','Montebello','5',1),('55475','Murindó','5',1),('5548','Mutatá','5',1),('55483','Nariño','5',1),('5549','Necoclí','5',1),('55495','Nechí','5',1),('55501','Olaya','5',1),('55541','Peñol','5',1),('55543','Peque','5',1),('55576','Pueblorrico','5',1),('55579','Puerto Berrío','5',1),('55585','Puerto Nare','5',1),('55591','Puerto Triunfo','5',1),('55604','Remedios','5',1),('55607','Retiro','5',1),('55615','Rionegro','5',1),('55628','Sabanalarga','5',1),('55631','Sabaneta','5',1),('55642','Salgar','5',1),('55647','San Andrés de Cuerquía','5',1),('55649','San Carlos','5',1),('55652','San Francisco','5',1),('55656','San Jerónimo','5',1),('55658','San José de La Montaña','5',1),('55659','San Juan de Urabá','5',1),('5566','San Luis','5',1),('55664','San Pedro','5',1),('55665','San Pedro de Uraba','5',1),('55667','San Rafael','5',1),('5567','San Roque','5',1),('55674','San Vicente','5',1),('55679','Santa Bárbara','5',1),('55686','Santa Rosa de Osos','5',1),('5569','Santo Domingo','5',1),('55697','El Santuario','5',1),('55736','Segovia','5',1),('55756','Sonsón','5',1),('55761','Sopetrán','5',1),('55789','Támesis','5',1),('5579','Tarazá','5',1),('55792','Tarso','5',1),('55809','Titiribí','5',1),('55819','Toledo','5',1),('55837','Turbo','5',1),('55842','Uramita','5',1),('55847','Urrao','5',1),('55854','Valdivia','5',1),('55856','Valparaíso','5',1),('55858','Vegachí','5',1),('55861','Venecia','5',1),('55873','Vigía del Fuerte','5',1),('55885','Yalí','5',1),('55887','Yarumal','5',1),('5589','Yolombó','5',1),('55893','Yondó','5',1),('55895','Zaragoza','5',1),('6363001','Armenia','63',1),('6363111','Buenavista','63',1),('636313','Calarcá','63',1),('636319','Circasia','63',1),('6363212','Córdoba','63',1),('6363272','Filandia','63',1),('6363302','Génova','63',1),('6363401','La Tebaida','63',1),('636347','Montenegro','63',1),('6363548','Pijao','63',1),('6363594','Quimbaya','63',1),('636369','Salento','63',1),('6666001','Pereira','66',1),('6666045','Apía','66',1),('6666075','Balboa','66',1),('6666088','Belén de Umbría','66',1),('666617','Dosquebradas','66',1),('6666318','Guática','66',1),('6666383','La Celia','66',1),('66664','La Virginia','66',1),('666644','Marsella','66',1),('6666456','Mistrató','66',1),('6666572','Pueblo Rico','66',1),('6666594','Quinchía','66',1),('6666682','Santa Rosa de Cabal','66',1),('6666687','Santuario','66',1),('6868001','Bucaramanga','68',1),('6868013','Aguada','68',1),('686802','Albania','68',1),('6868051','Aratoca','68',1),('6868077','Barbosa','68',1),('6868079','Barichara','68',1),('6868081','Barrancabermeja','68',1),('6868092','Betulia','68',1),('6868101','Bolívar','68',1),('6868121','Cabrera','68',1),('6868132','California','68',1),('6868147','Capitanejo','68',1),('6868152','Carcasí','68',1),('686816','Cepitá','68',1),('6868162','Cerrito','68',1),('6868167','Charalá','68',1),('6868169','Charta','68',1),('6868176','Chimá','68',1),('6868179','Chipatá','68',1),('686819','Cimitarra','68',1),('6868207','Concepción','68',1),('6868209','Confines','68',1),('6868211','Contratación','68',1),('6868217','Coromoro','68',1),('6868229','Curití','68',1),('6868235','El Carmen de Chucurí','68',1),('6868245','El Guacamayo','68',1),('686825','El Peñón','68',1),('6868255','El Playón','68',1),('6868264','Encino','68',1),('6868266','Enciso','68',1),('6868271','Florián','68',1),('6868276','Floridablanca','68',1),('6868296','Galán','68',1),('6868298','Gambita','68',1),('6868307','Girón','68',1),('6868318','Guaca','68',1),('686832','Guadalupe','68',1),('6868322','Guapotá','68',1),('6868324','Guavatá','68',1),('6868327','Güepsa','68',1),('6868344','Hato','68',1),('6868368','Jesús María','68',1),('686837','Jordán','68',1),('6868377','La Belleza','68',1),('6868385','Landázuri','68',1),('6868397','La Paz','68',1),('6868406','Lebríja','68',1),('6868418','Los Santos','68',1),('6868425','Macaravita','68',1),('6868432','Málaga','68',1),('6868444','Matanza','68',1),('6868464','Mogotes','68',1),('6868468','Molagavita','68',1),('6868498','Ocamonte','68',1),('68685','Oiba','68',1),('6868502','Onzaga','68',1),('6868522','Palmar','68',1),('6868524','Palmas del Socorro','68',1),('6868533','Páramo','68',1),('6868547','Piedecuesta','68',1),('6868549','Pinchote','68',1),('6868572','Puente Nacional','68',1),('6868573','Puerto Parra','68',1),('6868575','Puerto Wilches','68',1),('6868615','Rionegro','68',1),('6868655','Sabana de Torres','68',1),('6868669','San Andrés','68',1),('6868673','San Benito','68',1),('6868679','San Gil','68',1),('6868682','San Joaquín','68',1),('6868684','San José de Miranda','68',1),('6868686','San Miguel','68',1),('6868689','San Vicente de Chucurí','68',1),('6868705','Santa Bárbara','68',1),('686872','Santa Helena del Opón','68',1),('6868745','Simacota','68',1),('6868755','Socorro','68',1),('686877','Suaita','68',1),('6868773','Sucre','68',1),('686878','Suratá','68',1),('686882','Tona','68',1),('6868855','Valle de San José','68',1),('6868861','Vélez','68',1),('6868867','Vetas','68',1),('6868872','Villanueva','68',1),('6868895','Zapatoca','68',1),('7070001','Sincelejo','70',1),('707011','Buenavista','70',1),('7070124','Caimito','70',1),('7070204','Coloso','70',1),('7070215','Corozal','70',1),('7070221','Coveñas','70',1),('707023','Chalán','70',1),('7070233','El Roble','70',1),('7070235','Galeras','70',1),('7070265','Guaranda','70',1),('70704','La Unión','70',1),('7070418','Los Palmitos','70',1),('7070429','Majagual','70',1),('7070473','Morroa','70',1),('7070508','Ovejas','70',1),('7070523','Palmito','70',1),('707067','Sampués','70',1),('7070678','San Benito Abad','70',1),('7070702','San Juan de Betulia','70',1),('7070708','San Marcos','70',1),('7070713','San Onofre','70',1),('7070717','San Pedro','70',1),('7070742','San Luis de Sincé','70',1),('7070771','Sucre','70',1),('707082','Santiago de Tolú','70',1),('7070823','Tolú Viejo','70',1),('7373001','Ibagué','73',1),('7373024','Alpujarra','73',1),('7373026','Alvarado','73',1),('737303','Ambalema','73',1),('7373043','Anzoátegui','73',1),('7373055','Armero','73',1),('7373067','Ataco','73',1),('7373124','Cajamarca','73',1),('7373148','Carmen de Apicala','73',1),('7373152','Casabianca','73',1),('7373168','Chaparral','73',1),('73732','Coello','73',1),('7373217','Coyaima','73',1),('7373226','Cunday','73',1),('7373236','Dolores','73',1),('7373268','Espinal','73',1),('737327','Falan','73',1),('7373275','Flandes','73',1),('7373283','Fresno','73',1),('7373319','Guamo','73',1),('7373347','Herveo','73',1),('7373349','Honda','73',1),('7373352','Icononzo','73',1),('7373408','Lérida','73',1),('7373411','Líbano','73',1),('7373443','Mariquita','73',1),('7373449','Melgar','73',1),('7373461','Murillo','73',1),('7373483','Natagaima','73',1),('7373504','Ortega','73',1),('737352','Palocabildo','73',1),('7373547','Piedras','73',1),('7373555','Planadas','73',1),('7373563','Prado','73',1),('7373585','Purificación','73',1),('7373616','Rio Blanco','73',1),('7373622','Roncesvalles','73',1),('7373624','Rovira','73',1),('7373671','Saldaña','73',1),('7373675','San Antonio','73',1),('7373678','San Luis','73',1),('7373686','Santa Isabel','73',1),('737377','Suárez','73',1),('7373854','Valle de San Juan','73',1),('7373861','Venadillo','73',1),('737387','Villahermosa','73',1),('7373873','Villarrica','73',1),('7676001','Cali','76',1),('767602','Alcalá','76',1),('7676036','Andalucía','76',1),('7676041','Ansermanuevo','76',1),('7676054','Argelia','76',1),('76761','Bolívar','76',1),('7676109','Buenaventura','76',1),('7676111','Guadalajara de Buga','76',1),('7676113','Bugalagrande','76',1),('7676122','Caicedonia','76',1),('7676126','Calima','76',1),('767613','Candelaria','76',1),('7676147','Cartago','76',1),('7676233','Dagua','76',1),('7676243','El Águila','76',1),('7676246','El Cairo','76',1),('7676248','El Cerrito','76',1),('767625','El Dovio','76',1),('7676275','Florida','76',1),('7676306','Ginebra','76',1),('7676318','Guacarí','76',1),('7676364','Jamundí','76',1),('7676377','La Cumbre','76',1),('76764','La Unión','76',1),('7676403','La Victoria','76',1),('7676497','Obando','76',1),('767652','Palmira','76',1),('7676563','Pradera','76',1),('7676606','Restrepo','76',1),('7676616','Riofrío','76',1),('7676622','Roldanillo','76',1),('767667','San Pedro','76',1),('7676736','Sevilla','76',1),('7676823','Toro','76',1),('7676828','Trujillo','76',1),('7676834','Tuluá','76',1),('7676845','Ulloa','76',1),('7676863','Versalles','76',1),('7676869','Vijes','76',1),('767689','Yotoco','76',1),('7676892','Yumbo','76',1),('7676895','Zarzal','76',1),('8181001','Arauca','81',1),('8181065','Arauquita','81',1),('818122','Cravo Norte','81',1),('81813','Fortul','81',1),('8181591','Puerto Rondón','81',1),('8181736','Saravena','81',1),('8181794','Tame','81',1),('8585001','Yopal','85',1),('858501','Aguazul','85',1),('8585015','Chámeza','85',1),('8585125','Hato Corozal','85',1),('8585136','La Salina','85',1),('8585139','Maní','85',1),('8585162','Monterrey','85',1),('8585225','Nunchía','85',1),('858523','Orocué','85',1),('858525','Paz de Ariporo','85',1),('8585263','Pore','85',1),('8585279','Recetor','85',1),('85853','Sabanalarga','85',1),('8585315','Sácama','85',1),('8585325','San Luis de Gaceno','85',1),('85854','Támara','85',1),('858541','Tauramena','85',1),('858543','Trinidad','85',1),('858544','Villanueva','85',1),('8686001','Mocoa','86',1),('8686219','Colón','86',1),('868632','Orito','86',1),('8686568','Puerto Asís','86',1),('8686569','Puerto Caicedo','86',1),('8686571','Puerto Guzmán','86',1),('8686573','Leguízamo','86',1),('8686749','Sibundoy','86',1),('8686755','San Francisco','86',1),('8686757','San Miguel','86',1),('868676','Santiago','86',1),('8686865','Valle de Guamez','86',1),('8686885','Villagarzón','86',1),('88001','Barranquilla','8',1),('88078','Baranoa','8',1),('88137','Campo de La Cruz','8',1),('88141','Candelaria','8',1),('88296','Galapa','8',1),('88372','Juan de Acosta','8',1),('88421','Luruaco','8',1),('88433','Malambo','8',1),('88436','Manatí','8',1),('8852','Palmar de Varela','8',1),('88549','Piojó','8',1),('88558','Polonuevo','8',1),('8856','Ponedera','8',1),('88573','Puerto Colombia','8',1),('88606','Repelón','8',1),('88634','Sabanagrande','8',1),('88638','Sabanalarga','8',1),('88675','Santa Lucía','8',1),('88685','Santo Tomás','8',1),('88758','Soledad','8',1),('8877','Suan','8',1),('88832','Tubará','8',1),('88849','Usiacurí','8',1),('8888001','San Andrés','88',1),('8888564','Providencia','88',1),('9191001','Leticia','91',1),('9191263','El Encanto','91',1),('9191405','La Chorrera','91',1),('9191407','La Pedrera','91',1),('919143','La Victoria','91',1),('919146','Miriti Paraná','91',1),('919153','Puerto Alegría','91',1),('9191536','Puerto Arica','91',1),('919154','Puerto Nariño','91',1),('9191669','Puerto Santander','91',1),('9191798','Tarapacá','91',1),('9494001','Inírida','94',1),('9494343','Barranco Minas','94',1),('9494663','Mapiripana','94',1),('9494883','San Felipe','94',1),('9494884','Puerto Colombia','94',1),('9494885','La Guadalupe','94',1),('9494886','Cacahual','94',1),('9494887','Pana Pana','94',1),('9494888','Morichal','94',1),('9595001','San José del Guaviare','95',1),('9595015','Calamar','95',1),('9595025','El Retorno','95',1),('95952','Miraflores','95',1),('9797001','Mitú','97',1),('9797161','Caruru','97',1),('9797511','Pacoa','97',1),('9797666','Taraira','97',1),('9797777','Papunaua','97',1),('9797889','Yavaraté','97',1),('9999001','Puerto Carreño','99',1),('9999524','La Primavera','99',1),('9999624','Santa Rosalía','99',1),('9999773','Cumaribo','99',1);
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(200) NOT NULL,
  `correo` varchar(200) DEFAULT NULL,
  `celular` varchar(50) DEFAULT NULL,
  `idCiudad` varchar(50) DEFAULT NULL,
  `universidad` varchar(200) DEFAULT NULL,
  `idUsuario` int(11) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`idCliente`),
  KEY `IXFK_cliente_ciudad` (`idCiudad`),
  KEY `IXFK_cliente_usuario` (`idUsuario`),
  CONSTRAINT `FK_cliente_ciudad` FOREIGN KEY (`idCiudad`) REFERENCES `ciudad` (`idCiudad`),
  CONSTRAINT `FK_cliente_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'TETE 2 2','tete@tete.com','3124444567','1313052','PUJ',2,'2021-06-20 21:04:02','ADMIN','2021-06-23 02:33:01'),(2,'YUYU 2','yuyu@yuyu.com|','3123344556','1313074','PUJ',2,'2021-06-20 21:05:17','ADMIN','2021-06-22 19:47:10'),(3,'RETE 2','rete@rete.com','3214556789','1313006','PUJ',2,'2021-06-20 21:08:45','ADMIN','2021-06-22 19:47:22'),(4,'WILLIAM3 MORENO3','wmorneo@gmail.com','3125676567','4444035','PUJ',2,'2021-06-20 22:24:42',NULL,NULL),(5,'TETE 4','tete@tete.com','3123321321','1313006','FEFE',2,'2021-06-22 19:45:23',NULL,NULL),(6,'FINAL TEST C FULL NAME','final test c email','3123236789','131303','FINAL TEST C UNIVERSITY',2,'2021-06-23 02:33:44',NULL,NULL),(7,'ALEXANDER CORREO','williammorenoprieto@hotmail.com','3142345467','1111001','UNIVERSIDAD BUENA',2,'2021-07-04 14:31:13',NULL,NULL),(8,'WILLIAM','jair_acevedo@hotmail.com','3124567876','55001','VIDA',2,'2021-07-04 15:16:53',NULL,NULL),(9,'8AGO','8ago@8ago.com','3125678987','131376','8AGO UNI',2,'2021-08-08 20:11:43',NULL,NULL);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

--
-- Table structure for table `departamento`
--

DROP TABLE IF EXISTS `departamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamento` (
  `idDepartamento` varchar(50) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`idDepartamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamento`
--

/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
INSERT INTO `departamento` VALUES ('11','Bogotá D.C.',1),('13','Bolívar',1),('15','Boyacá',1),('17','Caldas',1),('18','Caquetá',1),('19','Cauca',1),('20','Cesar',1),('23','Córdoba',1),('25','Cundinamarca',1),('27','Chocó',1),('41','Huila',1),('44','La Guajira',1),('47','Magdalena',1),('5','Antioquia',1),('50','Meta',1),('52','Nariño',1),('54','Norte de Santander',1),('63','Quindío',1),('66','Risaralda',1),('68','Santander',1),('70','Sucre',1),('73','Tolima',1),('76','Valle del Cauca',1),('8','Atlántico',1),('81','Arauca',1),('85','Casanare',1),('86','Putumayo',1),('88','Archipiélago de San Andrés, Providencia y Santa Catalina',1),('91','Amazonas',1),('94','Guainía',1),('95','Guaviare',1),('97','Vaupés',1),('99','Vichada',1);
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado` (
  `idEstado` int(11) NOT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idEstado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` VALUES (1,'Registrado'),(2,'En Proceso'),(3,'Terminado'),(4,'Anulado');
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;

--
-- Table structure for table `solicitud`
--

DROP TABLE IF EXISTS `solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitud` (
  `idSolicitud` int(11) NOT NULL AUTO_INCREMENT,
  `idUsuario` int(11) DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL,
  `idTutor` int(11) DEFAULT NULL,
  `nombre_trabajo` varchar(500) DEFAULT NULL,
  `fecha_entrega` date DEFAULT NULL,
  `fecha_entrega_tutor` date DEFAULT NULL,
  `costo` int(11) NOT NULL DEFAULT 0,
  `ejecutor` int(11) DEFAULT NULL,
  `comision` int(11) NOT NULL DEFAULT 0,
  `utilidad` int(11) NOT NULL DEFAULT 0,
  `ahorro` int(11) NOT NULL DEFAULT 0,
  `inversion` int(11) NOT NULL DEFAULT 0,
  `diezmo` int(11) NOT NULL DEFAULT 0,
  `pagado` int(11) NOT NULL DEFAULT 0,
  `fecha_creacion` datetime DEFAULT NULL,
  `idEstado` int(11) DEFAULT NULL,
  `usr_modificacion` varchar(100) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`idSolicitud`),
  KEY `IXFK_solicitud_cliente` (`idCliente`),
  KEY `IXFK_solicitud_estado` (`idEstado`),
  KEY `IXFK_solicitud_tutor` (`idTutor`),
  KEY `IXFK_solicitud_usuario` (`idUsuario`),
  CONSTRAINT `FK_solicitud_cliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`),
  CONSTRAINT `FK_solicitud_estado` FOREIGN KEY (`idEstado`) REFERENCES `estado` (`idEstado`),
  CONSTRAINT `FK_solicitud_tutor` FOREIGN KEY (`idTutor`) REFERENCES `tutor` (`idTutor`),
  CONSTRAINT `FK_solicitud_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud`
--

/*!40000 ALTER TABLE `solicitud` DISABLE KEYS */;
INSERT INTO `solicitud` VALUES (1,2,1,1,'X','2021-02-01','2021-02-01',1,1,1,-1,0,0,0,0,'2021-07-03 14:33:29',1,'ADMIN','2021-08-08 22:15:21'),(2,2,1,2,'TRABAJO BD','2020-02-01','2020-02-01',100000,10,1,99989,29997,9999,9999,50,'2021-07-03 09:39:31',1,NULL,NULL),(3,2,1,1,'TRABAJO BACK EDIT','2021-02-01','2021-02-01',100000,10,1,99989,29997,9999,9999,50,'2021-07-03 09:42:11',1,'ADMIN','2021-07-03 09:48:13'),(4,2,1,17,'TRABAJO BACK 2','2021-02-01','2021-02-01',100000,10,1,99989,29997,9999,9999,50,'2021-07-03 11:54:18',1,NULL,NULL),(5,5,4,17,'FRONT','2021-07-04','2021-07-04',0,12,1222,-1234,-370,-123,-123,1,'2021-07-04 10:19:03',1,'PIPILOCO','2021-07-04 10:59:34'),(6,2,7,18,'VUELTAS CHIMBAS','2021-09-02','2021-09-02',0,10,200000,-200010,-60003,-20001,-20001,0,'2021-07-04 14:58:21',3,'williammorenoprieto@gmail.com','2021-07-04 15:07:12'),(7,5,8,19,'TRABAJO DE PRUEBA 15:17','2021-08-01','2021-08-01',0,10,200000,-200010,-60003,-20001,-20001,0,'2021-07-04 15:18:11',1,'PIPILOCO','2021-07-04 15:26:07'),(8,1,7,18,'TETE','2021-07-08','2021-07-08',1000000,345345,987979,-333324,-99997,-33332,-33332,0,'2021-07-08 17:48:42',3,'developer','2021-08-09 21:56:55'),(9,2,9,20,'AGO8TUTO TRABAJO','2021-08-13','2021-08-13',10000,10000000,100000,-10090000,-3027000,-1009000,-1009000,0,'2021-08-08 20:55:48',1,'ADMIN','2021-08-08 22:15:02'),(10,1,1,1,'FAQWADSA','2021-08-08','2021-08-08',12341234,13123,234124,12093987,3628196,1209399,1209399,0,'2021-08-08 22:17:49',2,'developer','2021-08-09 21:30:16'),(11,1,7,18,'TEST CREATE MAIL','2021-08-14','2021-08-14',123123123,123,123123,122999877,36899963,12299988,12299988,0,'2021-08-09 21:59:11',1,NULL,NULL);
/*!40000 ALTER TABLE `solicitud` ENABLE KEYS */;

--
-- Table structure for table `tutor`
--

DROP TABLE IF EXISTS `tutor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tutor` (
  `idTutor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(200) DEFAULT NULL,
  `profesion` varchar(500) DEFAULT NULL,
  `correo` varchar(200) DEFAULT NULL,
  `telefono` varchar(200) DEFAULT NULL,
  `idCiudad` varchar(50) DEFAULT NULL,
  `universidad` varchar(500) DEFAULT NULL,
  `habilidades` varchar(2000) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  `idUsuario` int(11) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`idTutor`),
  KEY `IXFK_tutor_ciudad` (`idCiudad`),
  KEY `IXFK_tutor_usuario` (`idUsuario`),
  CONSTRAINT `FK_tutor_ciudad` FOREIGN KEY (`idCiudad`) REFERENCES `ciudad` (`idCiudad`),
  CONSTRAINT `FK_tutor_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutor`
--

/*!40000 ALTER TABLE `tutor` DISABLE KEYS */;
INSERT INTO `tutor` VALUES (1,'WM 3','PR','pr@gmail.com','3224444555','1313006','PUJ','MUCHAS',0,2,'2021-06-19 16:59:55','ADMIN','2021-06-23 13:54:52'),(2,'WILLIAM MORENO 2 2 2','INGENIERO','example@example.com','3056765676','1313006','PUJ','SISTEMAS, DESARROLLO',1,2,'2021-06-19 17:07:34','ADMIN','2021-06-22 12:41:00'),(3,'ALEXANDER MORENO','INGENIERO','example@example.com','3056765676','1313006','PUJ','SISTEMAS, DESARROLLO',0,2,'2021-06-19 17:12:23','ADMIN','2021-06-22 12:41:09'),(4,'TEST MORENO','INGENIERO','example@example.com','3056765676','1313006','PUJ','SISTEMAS, DESARROLLO',0,2,'2021-06-19 17:16:11','ADMIN','2021-06-22 12:43:48'),(5,'JOSE JOSE','TET','asdas@tetet.com','3213786787','1313001','TOTO','MATHS',0,2,'2021-06-19 17:23:22','ADMIN','2021-06-22 13:51:33'),(6,'JOSE JOSE','TET','asdas@tetet.com','3213786787','1313001','TOTO','MATHS',1,2,'2021-06-20 17:24:01',NULL,NULL),(7,'TETE','TETE','tete','342432432','1313042','TETEETE','SISTEMAS, DESARROLLO',0,2,'2021-06-20 17:30:06','ADMIN','2021-06-22 12:43:59'),(8,'EWEW','EWEWE','wewewe','32432423423','1313001','WERWER','WERWER',1,2,'2021-06-20 17:32:11',NULL,NULL),(9,'SDFSDF','ASDASDASD','sdfsdfsd@asdasd.com','313123123','1313006','ASFDASDF','SADFASDF',1,2,'2021-06-20 21:39:18',NULL,NULL),(10,'WILLIAM2 MORENO2','INGENIERO','william@example.com','3125678987','1313667','PUJ','MATEMATICAS, CALCULO',1,2,'2021-06-20 22:23:15',NULL,NULL),(11,'TETE','TETE','tete@tete','31231223212','1313052','TETE','TETEE TETE ET E',0,2,'2021-06-22 21:35:52','ADMIN','2021-06-22 21:37:27'),(12,'FINAL TEST FULL NAME 2 2','FINAL TEST PROFILE','final test email','3127898765','1313006','FINAL TEST UNIVERSITY','FINAL TEST HABILITIES 2',1,2,'2021-06-23 02:20:11','ADMIN','2021-06-23 02:25:54'),(13,'TEST DEPLOY','DEVOPS','deploy@deploy.com','3125676678','1313006','DEPLOY UNIVERSITY','DEVOPS',1,2,'2021-06-23 13:21:48',NULL,NULL),(14,'TUTOR DE PRUEBA2','PROFESOR','correoprueba@correo.com','315315311','6666001','UNIVERSIDAD','HABILIDAD',1,2,'2021-06-23 19:06:42','ADMIN','2021-06-23 19:06:55'),(15,'CAROLINA GONZALES','CONTADORA','tesosentesis@gmail.com','3158157851','6868001','UPB','CONTABILIDAD',1,2,'2021-06-25 12:34:19',NULL,NULL),(16,'SEBASTIAN ACOSTA','ING DE ALIMENTOS','sebitas','45454535','1717001','UNIVERSIDAD DE CALDAS','NO SE HACE NADA',1,2,'2021-06-25 15:22:02',NULL,NULL),(17,'TUTOR CON CLAVE','T','tutor@correo.com','400','1111001','T','T',1,2,'2021-06-25 16:36:27','TUTOR@CORREO.COM','2021-06-25 16:37:20'),(18,'WILLIAM CORREO','INGENIERO','williammorenoprieto@gmail.com','3125566765','1111001','BUENA UNIVERSIDAD','MUCAS',1,2,'2021-07-04 14:29:03',NULL,NULL),(19,'JAIR','CANTANTE','acevedojair@gmail.com','3125676545','1111001','TEST','MUCHAS',1,2,'2021-07-04 15:15:56',NULL,NULL),(20,'AGO8TUTO','AGO8TUTO PROFE','ago8tuto@ago8tuto.com','3124657654','2525758','AGO8TUTO UNI','AGO8TUTO HAB',1,2,'2021-08-08 20:53:16',NULL,NULL);
/*!40000 ALTER TABLE `tutor` ENABLE KEYS */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `clave` varchar(2000) DEFAULT NULL,
  `fecha_creacion` date DEFAULT NULL,
  `tipo` varchar(1) DEFAULT NULL COMMENT 'P: Propetario\r\n	A: Administrador\r\n	T: Tutor\r\n	C: Cliente',
  `id_interno` int(11) NOT NULL DEFAULT -1,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Desarrollador','developer','developer','2021-06-01','A',-1),(2,'Administrador','admin','admin','2021-06-01','A',-1),(5,'William','pipiloco','pipiloco','2021-06-01','P',-1),(6,'tutor con clave','tutor@correo.com','400','2021-06-25','T',17),(7,'William Correo','williammorenoprieto@gmail.com','3125566765','2021-07-04','T',18),(8,'Jair','acevedojair@gmail.com','3125676545','2021-07-04','T',19),(9,'AGO8TUTO','ago8tuto@ago8tuto.com','3124657654','2021-08-08','T',20);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

--
-- Dumping routines for database 'u290874471_db_tesos'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `autenticacion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `autenticacion`(IN `p_usuario` VARCHAR(100), IN `p_clave` VARCHAR(100))
BEGIN
	DECLARE numreg INT DEFAULT 0;
    
   select count(1) into numreg
    from usuario u
    where upper(u.usuario) = upper(p_usuario)
    and upper(u.clave) = upper(p_clave);
    
    if numreg > 0 then
		select u.usuario, u.tipo, u.clave, ifnull(t.idTutor,-1) id_interno
        from usuario u
        left outer join tutor t on upper(u.usuario) = upper(t.correo)
        where upper(u.usuario) = upper(p_usuario);
	else
		select 'no autorizado' usuario, 'x' tipo, 'su madre' clave
        from dual;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getClientes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `getClientes`()
BEGIN
	select c.idCliente id, c.nombre_completo cliente
    from cliente c;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getEstados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `getEstados`()
BEGIN
	select e.idEstado id, e.descripcion estado
    from estado e;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getResumen` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `getResumen`(in p_anio int, in p_pagado int)
BEGIN

	select 'Enero' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/01','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/01','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Febrero' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/02','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/02','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Marzo' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/03','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/03','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Abril' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/04','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/04','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Mayo' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/05','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/05','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Junio' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/06','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/06','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Julio' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/07','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/07','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Agosto' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/08','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/08','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Septiembre' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/09','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/09','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Octubre' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/10','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/10','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Noviembre' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/11','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/11','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado
    union
	select 'Diciembre' Mes, ifnull(sum(ifnull(s.costo,0)),0) costo,
	ifnull(sum(ifnull(s.ejecutor,0)),0) ejecutor,
	ifnull(sum(ifnull(s.comision,0)),0) comision,
	ifnull(sum(ifnull(s.utilidad,0)),0) utilidad,
	ifnull(sum(ifnull(s.ahorro,0)),0) ahorro,
	ifnull(sum(ifnull(s.inversion,0)),0) inversion,
	ifnull(sum(ifnull(s.diezmo,0)),0) diezmo
	from solicitud s
	where date(s.fecha_creacion) between STR_TO_DATE(concat('01/12','/',p_anio),'%d/%m/%Y') and LAST_DAY(STR_TO_DATE(concat('01/12','/',p_anio),'%d/%m/%Y'))
	and s.pagado = p_pagado ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getTutores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `getTutores`()
BEGIN
	select t.idTutor id, t.nombre_completo tutor
    from tutor t;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getubidaciones` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `getubidaciones`()
BEGIN
	select c.idCiudad id, CONCAT(upper(c.nombre),' [',d.nombre,']') descripcion
    from departamento d
    inner join ciudad c on d.idDepartamento = c.idDepartamento
    where d.activo = 1
    and c.activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `prc_conf_cliente` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `prc_conf_cliente`(IN `p_transaccion` VARCHAR(1), IN `p_id_cliente` INT, IN `p_nombre_completo` VARCHAR(200), IN `p_correo` VARCHAR(200), IN `p_celular` VARCHAR(50), IN `p_id_ciudad` VARCHAR(50), IN `p_universidad` VARCHAR(200), IN `p_usuario` VARCHAR(50), IN `p_fecha_inicio` VARCHAR(10), IN `p_fecha_fin` VARCHAR(10))
BEGIN
	
    declare valor int;
    declare vError int default 0;
	DECLARE vIdUsuario INT DEFAULT -1;
    DECLARE vDate datetime DEFAULT CURRENT_TIMESTAMP();
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 @ERRNO = MYSQL_ERRNO, @MESSAGE_TEXT = MESSAGE_TEXT;
		SELECT 'ERROR' AS STATUS, CONCAT('MySQL ERROR: ', @ERRNO, ': ', @MESSAGE_TEXT) AS MESSAGE;
        set vError = 1;
	END;

	if vError = 1 then
		rollback;
	else
		set p_transaccion = upper(p_transaccion);
		select date_add(now(),interval -5 hour) into vDate;
        
		select IFNULL(u.idUsuario,-2) into vIdUsuario
		from usuario u
		where upper(u.usuario) = upper(p_usuario);
		   
		if(p_transaccion = 'I' and vIdUsuario > 0) THEN
			INSERT INTO cliente
			(`nombre_completo`,
			`correo`,
			`celular`,
			`idCiudad`,
			`universidad`,
			`idUsuario`,
			`fecha_creacion`)
			VALUES
			(
			trim(upper(p_nombre_completo)),
			trim(lower(p_correo)),
			trim(p_celular),
			p_id_ciudad,
			trim(upper(p_universidad)),
			vIdUsuario,
			vDate);

			select 1 id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'U' and vIdUsuario > 0) THEN
			UPDATE cliente
			SET
			`nombre_completo` = trim(upper(p_nombre_completo)),
			`correo` = trim(lower(p_correo)),
			`celular` = trim(p_celular),
			`idCiudad` = p_id_ciudad,
			`universidad` = trim(upper(p_universidad)),
            `usr_modificacion` = upper(p_usuario),
            `fecha_modificacion` = vDate
			WHERE `idCliente` = p_id_cliente;

			select 1 id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'C') THEN
			select t.idCliente,
            t.nombre_completo,
            t.correo,
            t.celular,
            c.idCiudad,
            c.nombre ciudad,
            t.universidad,
            u.usuario usr_creacion,
            t.fecha_creacion,
            t.usr_modificacion,
            t.fecha_modificacion,
            (select count(1) from solicitud s where s.idCliente = t.idCliente) cantidad_trabajos,
			(select sum(ifnull(s.costo,0)) from solicitud s where s.idCliente = t.idCliente) valor_trabajos
			from cliente t
            inner join ciudad c on t.idCiudad = c.idCiudad
			inner join usuario u on t.idUsuario = u.idUsuario
			where t.idCliente  > 0
            and vIdUsuario > 0
            and 1 = case when p_id_cliente > 0 then 1 
						 when p_id_cliente = -1 and date(t.fecha_Creacion) between STR_TO_DATE(p_fecha_inicio,'%d/%m/%Y') and STR_TO_DATE(p_fecha_fin,'%d/%m/%Y') then 1
                         else 0 end 
            and t.idCliente = case when p_id_cliente > 0 then p_id_cliente else t.idCliente end ;
			
		else
			select -1 id, 'Error en Transaccion' Descripcion
			from dual;
		end if;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `prc_conf_solicitud` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `prc_conf_solicitud`(IN `p_transaccion` VARCHAR(2), IN `p_id_solicitud` INT, IN `p_id_cliente` INT, IN `p_id_tutor` INT, IN `p_nombre_trabajo` VARCHAR(500), IN `p_fecha_entrega` VARCHAR(10), IN `p_costo` INT, IN `p_porc_ejecutor` INT, IN `p_comision` INT, IN `p_pagado` INT, IN `p_id_estado` INT, IN `p_usuario` VARCHAR(50), IN `p_fecha_inicio` VARCHAR(10), IN `p_fecha_fin` VARCHAR(10), IN `p_fecha_entrega_tutor` VARCHAR(10))
BEGIN
	
    declare vError int default 0;
	DECLARE vIdUsuario INT DEFAULT -1;
    DECLARE vDate datetime DEFAULT CURRENT_TIMESTAMP();
    declare vUtilidad int default 0;
    declare vAhorro int default 0;
    declare vInversion int default 0;
    declare vDiezmo int default 0;
    declare vIdSolicitud int default 0;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 @ERRNO = MYSQL_ERRNO, @MESSAGE_TEXT = MESSAGE_TEXT;
		SELECT 'ERROR' AS STATUS, CONCAT('MySQL ERROR: ', @ERRNO, ': ', @MESSAGE_TEXT) AS MESSAGE;
        set vError = 1;
	END;

	if vError = 1 then
		rollback;
	else
		set p_transaccion = upper(p_transaccion);
        select date_add(now(),interval -5 hour) into vDate;
        
		select IFNULL(u.idUsuario,-2) into vIdUsuario
		from usuario u
		where upper(u.usuario) = upper(p_usuario);

		set vUtilidad = p_costo - IFNULL(p_comision,0) - IFNULL(p_porc_ejecutor,0);
		set vAhorro = ROUND(vUtilidad * 0.3);
		set vInversion = ROUND(vUtilidad * 0.1);
		set vDiezmo = ROUND(vUtilidad * 0.1);
		   
		if(p_transaccion = 'I' and vIdUsuario > 0) THEN
        
			INSERT INTO `solicitud`
			(`idUsuario`,
			`idCliente`,
			`idTutor`,
			`nombre_trabajo`,
			`fecha_entrega`,
            `fecha_entrega_tutor`,
			`costo`,
			`ejecutor`,
			`comision`,
			`utilidad`,
			`ahorro`,
			`inversion`,
			`diezmo`,
			`pagado`,
			`fecha_creacion`,
			`idEstado`)
			VALUES
			(vIdUsuario,
			p_id_cliente,
			p_id_tutor,
			upper(p_nombre_trabajo),
			STR_TO_DATE(p_fecha_entrega,'%d/%m/%Y'),
            STR_TO_DATE(p_fecha_entrega_tutor,'%d/%m/%Y'),
			p_costo,
			p_porc_ejecutor,
			p_comision,
			vUtilidad,
			vAhorro,
			vInversion,
			vDiezmo,
			p_pagado,
			vDate,
			p_id_estado);
            
            select max(s.idSolicitud) into vIdSolicitud
            from solicitud s
            where s.idUsuario = vIdUsuario
            and s.idCliente = p_id_cliente
            and s.idTutor = p_id_tutor;
            
			select vIdSolicitud id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'U' and vIdUsuario > 0) THEN
			UPDATE `solicitud`
			SET
			`idUsuario` = vIdUsuario,
			`idCliente` = p_id_cliente,
			`idTutor` = p_id_tutor,
			`nombre_trabajo` = upper(p_nombre_trabajo),
			`fecha_entrega` = STR_TO_DATE(p_fecha_entrega,'%d/%m/%Y'),
            `fecha_entrega_tutor` = STR_TO_DATE(p_fecha_entrega_tutor,'%d/%m/%Y'),
			`costo` = p_costo,
			`ejecutor` = p_porc_ejecutor,
			`comision` = p_comision,
			`utilidad` = vUtilidad,
			`ahorro` = vAhorro,
			`inversion` = vInversion,
			`diezmo` = vDiezmo,
			`pagado` = p_pagado,
			`idEstado` = p_id_estado,
			`usr_modificacion` =upper(p_usuario),
			`fecha_modificacion` =vDate
			WHERE `idSolicitud` = p_id_solicitud;

			select 1 id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'CP') THEN
			select s.idSolicitud,
            s.idUsuario,
            upper(u.usuario) usuario,
            c.nombre_completo cliente,
            t.nombre_completo tutor, 
            s.nombre_trabajo,
            s.fecha_entrega,
            s.costo,
            s.ejecutor,
            s.comision,
            s.utilidad,
            s.ahorro,
            s.inversion,
            s.diezmo,
            case when s.pagado = 1 then 'SI' else 'NO' end pagado,
            e.descripcion estado,
            ifnull(s.usr_modificacion,'') usr_modificacion,
            s.fecha_modificacion,
            t.correo correo_tutor,
            c.correo correo_cliente, 
            s.fecha_creacion,
            s.fecha_entrega_tutor
            from solicitud s
            inner join estado e on s.idEstado = e.idEstado
            inner join cliente c on s.idCliente = c.idCliente
            inner join usuario u on s.idUsuario = u.idUsuario
            inner join tutor t on s.idTutor = t.idTutor
			where vIdUsuario > 0
            and 1 = case when p_id_solicitud > 0 then 1 
						 when p_id_solicitud = -1 and date(t.fecha_Creacion) between STR_TO_DATE(p_fecha_inicio,'%d/%m/%Y') and STR_TO_DATE(p_fecha_fin,'%d/%m/%Y') then 1
                         else 0 end
            and c.idCliente = case when p_id_cliente > 0 then p_id_cliente else c.idCliente end 
            and s.idSolicitud = case when p_id_solicitud = -1 then s.idSolicitud else p_id_solicitud end ;
		elseif(p_transaccion = 'CT') THEN
			select s.idSolicitud,
            s.idUsuario,
            upper(u.usuario) usuario,
            c.nombre_completo cliente,
            s.nombre_trabajo,
            s.fecha_entrega_tutor fecha_entrega,
            s.ejecutor,
            e.descripcion estado,
            ifnull(s.usr_modificacion,'') usr_modificacion,
            s.fecha_modificacion,
            t.correo correo_tutor,
            c.correo correo_cliente,
            s.fecha_creacion
            from solicitud s
            inner join estado e on s.idEstado = e.idEstado
            inner join cliente c on s.idCliente = c.idCliente
            inner join usuario u on s.idUsuario = u.idUsuario
            inner join tutor t on s.idTutor = t.idTutor
			where vIdUsuario > 0
            and t.idTutor = p_id_tutor
            and 1 = case when p_id_solicitud = -1 then 1 
						 when date(t.fecha_Creacion) between STR_TO_DATE(p_fecha_inicio,'%d/%m/%Y') and STR_TO_DATE(p_fecha_fin,'%d/%m/%Y') then 1
                         else 0 end
            and c.idCliente = case when p_id_cliente > 0 then p_id_cliente else c.idCliente end 
            and s.idSolicitud = case when p_id_solicitud = -1 then s.idSolicitud else p_id_solicitud end ;
		elseif(p_transaccion = 'CA') THEN
			select s.idSolicitud,
            s.idUsuario,
            upper(u.usuario) usuario,
            c.nombre_completo cliente,
            t.nombre_completo tutor, 
            s.nombre_trabajo,
            s.fecha_entrega,
            s.costo,
            s.ejecutor,
            s.comision,
            e.descripcion estado,
            ifnull(s.usr_modificacion,'') usr_modificacion,
            s.fecha_modificacion,
            t.correo correo_tutor,
            c.correo correo_cliente,
            s.fecha_creacion,
            s.fecha_entrega_tutor
            from solicitud s
            inner join estado e on s.idEstado = e.idEstado
            inner join cliente c on s.idCliente = c.idCliente
            inner join usuario u on s.idUsuario = u.idUsuario
            inner join tutor t on s.idTutor = t.idTutor
			where vIdUsuario > 0
            and 1 = case when p_id_solicitud = -1 then 1 
						 when date(t.fecha_Creacion) between STR_TO_DATE(p_fecha_inicio,'%d/%m/%Y') and STR_TO_DATE(p_fecha_fin,'%d/%m/%Y') then 1
                         else 0 end
            and c.idCliente = case when p_id_cliente > 0 then p_id_cliente else c.idCliente end 
            and s.idSolicitud = case when p_id_solicitud = -1 then s.idSolicitud else p_id_solicitud end ;
		else
			select -1 id, 'Error en Transaccion' Descripcion
			from dual;
		end if;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `prc_conf_tutor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `prc_conf_tutor`(IN `p_transaccion` VARCHAR(1), IN `p_id_tutor` INT, IN `p_nombre_completo` VARCHAR(200), IN `p_profesion` VARCHAR(500), IN `p_correo` VARCHAR(200), IN `p_telefono` VARCHAR(200), IN `p_id_ciudad` VARCHAR(50), IN `p_universidad` VARCHAR(500), IN `p_habilidades` VARCHAR(2000), IN `p_activo` INT, IN `p_usuario` VARCHAR(50), IN `p_fecha_inicio` VARCHAR(10), IN `p_fecha_fin` VARCHAR(10))
BEGIN
	
    declare valor int;
    declare vError int default 0;
	DECLARE vIdUsuario INT DEFAULT -1;
    DECLARE vDate datetime DEFAULT CURRENT_TIMESTAMP();
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 @ERRNO = MYSQL_ERRNO, @MESSAGE_TEXT = MESSAGE_TEXT;
		SELECT 'ERROR' AS STATUS, CONCAT('MySQL ERROR: ', @ERRNO, ': ', @MESSAGE_TEXT) AS MESSAGE;
        set vError = 1;
	END;

	if vError = 1 then
		rollback;
	else
		set p_transaccion = upper(p_transaccion);
		select date_add(now(),interval -5 hour) into vDate;
        
		select IFNULL(u.idUsuario,-2) into vIdUsuario
		from usuario u
		where upper(u.usuario) = upper(p_usuario);
		   
		if(p_transaccion = 'I' and vIdUsuario > 0) THEN
			INSERT INTO `tutor`
						(`nombre_completo`,
						`profesion`,
						`correo`,
						`telefono`,
						`idCiudad`,
						`universidad`,
						`habilidades`,
						`activo`,
						`idUsuario`,
						`fecha_creacion`,
						`usr_modificacion`,
						`fecha_modificacion`)
						VALUES
						(trim(upper(p_nombre_completo)),
						trim(upper(p_profesion)),
						trim(lower(p_correo)),
						trim(p_telefono),
						p_id_ciudad,
						trim(upper(p_universidad)),
						trim(upper(p_habilidades)),
						p_activo,
						vIdUsuario,
						vDate,
						NULL,
						NULL);
			select t.idTutor into vIdUsuario
            from tutor t
            where t.correo = trim(lower(p_correo));
            
			insert into usuario(nombre,usuario,clave,fecha_creacion, tipo, id_interno) 
            values(p_nombre_completo, trim(lower(p_correo)), trim(p_telefono), vDate, 'T', vIdUsuario);
            
			select 1 id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'U' and vIdUsuario > 0) THEN
				UPDATE `tutor`
					SET
					`nombre_completo` =trim(upper(p_nombre_completo)),
					`profesion` =trim(upper(p_profesion)),
					`correo` = trim(lower(p_correo)),
					`telefono` =trim(p_telefono),
					`idCiudad` = p_id_ciudad,
					`universidad` = trim(upper(p_universidad)),
					`habilidades` =trim(upper(p_habilidades)),
					`activo` = p_activo,
					`usr_modificacion` =upper(p_usuario),
					`fecha_modificacion` =vDate
					WHERE `idTutor` = p_id_tutor;
                    
                    update usuario s set s.clave = trim(p_telefono), s.usuario = trim(lower(p_correo)) 
                    where s.id_interno = p_id_tutor
                    and s.tipo = 'T';

			select 1 id, 'Transacción Exitosa' Descripcion
			from dual;
		elseif(p_transaccion = 'C') THEN
			select t.idTutor,
				t.nombre_completo,
				t.profesion,
				t.correo,
				t.telefono,
				c.nombre ciudad,
                c.idCiudad,
				t.universidad,
				t.habilidades,
				t.activo,
				u.usuario usuario_creacion,
				t.fecha_creacion,
				t.usr_modificacion,
				t.fecha_modificacion,
				(select count(1) from solicitud s where s.idTutor = t.idTutor) cantidad_trabajos,
				ifnull((select sum(ifnull(s.costo,0)) from solicitud s where s.idTutor = t.idTutor),0) valor_trabajos
			from tutor t
			inner join usuario u on t.idUsuario = u.idUsuario
            inner join ciudad c on t.idCiudad = c.idCiudad
			where t.idTutor  > 0
            and vIdUsuario > 0
            and 1 = case when p_id_tutor > 0 then 1 
						 when p_id_tutor = -1 and date(t.fecha_Creacion) between STR_TO_DATE(p_fecha_inicio,'%d/%m/%Y') and STR_TO_DATE(p_fecha_fin,'%d/%m/%Y') then 1
                         else 0 end             
            and t.idTutor = case when p_id_tutor > 0 then p_id_tutor else t.idTutor end ;
			
		else
			select -1 id, 'Error en Transaccion' Descripcion
			from dual;
		end if;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `prc_set_estado_solicitud` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`u290874471_tesosadmin`@`127.0.0.1` PROCEDURE `prc_set_estado_solicitud`(IN `p_id_solicitud` INT, IN `p_id_estado` INT, IN `p_usuario` VARCHAR(50))
BEGIN
	
    declare vError int default 0;
	DECLARE vIdUsuario INT DEFAULT -1;
    DECLARE vDate datetime DEFAULT CURRENT_TIMESTAMP();
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 @ERRNO = MYSQL_ERRNO, @MESSAGE_TEXT = MESSAGE_TEXT;
		SELECT 'ERROR' AS STATUS, CONCAT('MySQL ERROR: ', @ERRNO, ': ', @MESSAGE_TEXT) AS MESSAGE;
        set vError = 1;
	END;

	if vError = 1 then
		rollback;
	else
       select date_add(now(),interval -5 hour) into vDate;
		select IFNULL(u.idUsuario,-2) into vIdUsuario
		from usuario u
		where upper(u.usuario) = upper(p_usuario);
        
        if vIdUsuario > 0 then
			update solicitud s set s.idEstado = p_id_estado, s.usr_modificacion = p_usuario, s.fecha_modificacion = vDate
            where s.idSolicitud = p_id_solicitud;		   
			
            select 1 id, 'Transaccion Exitosa' Descripcion
            from dual;			
		else
			select -1 id, 'Error en Transaccion' Descripcion
			from dual;
		end if;

    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-27 20:09:12
