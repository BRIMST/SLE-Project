-- MariaDB dump 10.19  Distrib 10.6.14-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u290874471_db_pedidos
-- ------------------------------------------------------
-- Server version	10.6.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alistamiento`
--

DROP TABLE IF EXISTS `alistamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alistamiento` (
  `id_alistamiento` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_pedido_dtl` bigint(20) NOT NULL,
  `id_zona` int(11) NOT NULL DEFAULT -1,
  `cantidad_alistada` int(11) NOT NULL,
  `fecha_alistamiento` datetime NOT NULL,
  `usr_alistamiento` varchar(50) NOT NULL,
  `comentario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_alistamiento`),
  KEY `IXFK_alistamiento_pedido_dtl` (`id_pedido_dtl`),
  CONSTRAINT `FK_alistamiento_pedido_dtl` FOREIGN KEY (`id_pedido_dtl`) REFERENCES `pedido_dtl` (`id_pedido_dtl`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alistamiento`
--

/*!40000 ALTER TABLE `alistamiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `alistamiento` ENABLE KEYS */;

--
-- Table structure for table `banco`
--

DROP TABLE IF EXISTS `banco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banco` (
  `id_banco` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banco`
--

/*!40000 ALTER TABLE `banco` DISABLE KEYS */;
INSERT INTO `banco` VALUES (-1,'No Aplica',1),(1,'Bancolombia',1),(2,'Banco de Bogotá',1),(3,'Davivienda',1),(4,'BBVA',1),(5,'Banco de Occidente',1),(6,'Scotiabank Colpatria',1),(7,'Banco Itaú',1),(8,'GNB Sudameris',1),(9,'Banco Agrario',1),(10,'Banco Popular',1),(11,'Banco Caja Social',1),(12,'Banco AV Villas',1),(13,'Banco Union',1),(14,'Bancoomeva',1),(15,'Banco Falabella',1),(16,'Banco Pichincha',1),(17,'Banco W',1),(18,'Banco Finandina',1),(19,'Bancamía',1),(20,'Banco Credifinanciera',1),(21,'Banco Cooperativo Coopcentral',1),(22,'Bancoldex',1);
/*!40000 ALTER TABLE `banco` ENABLE KEYS */;

--
-- Table structure for table `carrito`
--

DROP TABLE IF EXISTS `carrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carrito` (
  `id_carrito` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `IdProducto` int(11) NOT NULL,
  `codigo_barras` varchar(50) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `nombre_producto` varchar(100) NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `sucursal` varchar(100) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` int(11) NOT NULL,
  `porc_impuesto` int(11) NOT NULL,
  `asesor` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL,
  `url_imagen_prd` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_carrito`),
  UNIQUE KEY `uniq_prod_cte` (`IdProducto`),
  KEY `IXFK_carrito_cliente` (`id_cliente`),
  CONSTRAINT `FK_carrito_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `check_cantidad_pedido` CHECK (`cantidad` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrito`
--

/*!40000 ALTER TABLE `carrito` DISABLE KEYS */;
/*!40000 ALTER TABLE `carrito` ENABLE KEYS */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `id_tipo_documento` int(11) NOT NULL,
  `documento` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefonos` varchar(100) NOT NULL,
  `id_departamento` varchar(50) NOT NULL,
  `departamento` varchar(100) NOT NULL,
  `id_ciudad` varchar(50) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `id_cliente_referidor` int(11) NOT NULL DEFAULT -1,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `IXFK_cliente_tipo_documento` (`id_tipo_documento`),
  KEY `ix_cte_email` (`email`),
  KEY `ix_cte_documento` (`documento`),
  CONSTRAINT `FK_cliente_tipo_documento` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id_tipo_documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Alejandro','Acevedo',1,'4519299','alejandro.acevedo@gmail.com','300790000','5','Antioquia','5001','Medellín','San Diego',-1,1,'DEVELOPER','2023-07-17 20:22:04',NULL,NULL),(2,'Frank','Leon',1,'80727265','kagurezama@gmail.com','3013273733','11','Bogotá D.C.','11001','Bogotá D.C.','Calle 19sur #69-50 Piso 3',-1,1,'DEVELOPER','2023-07-17 20:23:03','administrador','2023-07-19 12:19:37');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

--
-- Table structure for table `conductor`
--

DROP TABLE IF EXISTS `conductor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conductor` (
  `id_conductor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `id_tipo_documento` int(11) NOT NULL,
  `documento` varchar(50) NOT NULL,
  `vehiculo` varchar(100) NOT NULL,
  `placa` varchar(10) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_conductor`),
  KEY `IXFK_conductor_tipo_documento` (`id_tipo_documento`),
  CONSTRAINT `FK_conductor_tipo_documento` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id_tipo_documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conductor`
--

/*!40000 ALTER TABLE `conductor` DISABLE KEYS */;
/*!40000 ALTER TABLE `conductor` ENABLE KEYS */;

--
-- Table structure for table `despacho`
--

DROP TABLE IF EXISTS `despacho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `despacho` (
  `id_despacho` int(11) NOT NULL AUTO_INCREMENT,
  `id_conductor` int(11) NOT NULL,
  `usr_creacion` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `comentario` varchar(100) DEFAULT NULL,
  `estado` varchar(50) NOT NULL,
  PRIMARY KEY (`id_despacho`),
  KEY `IXFK_despacho_conductor` (`id_conductor`),
  CONSTRAINT `FK_despacho_conductor` FOREIGN KEY (`id_conductor`) REFERENCES `conductor` (`id_conductor`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `despacho`
--

/*!40000 ALTER TABLE `despacho` DISABLE KEYS */;
/*!40000 ALTER TABLE `despacho` ENABLE KEYS */;

--
-- Table structure for table `despacho_dtl`
--

DROP TABLE IF EXISTS `despacho_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `despacho_dtl` (
  `id_despacho_dtl` int(11) NOT NULL AUTO_INCREMENT,
  `id_despacho` int(11) NOT NULL,
  `id_pedido` bigint(20) NOT NULL,
  `orden_entrega` int(11) NOT NULL,
  `fecha_entrega` datetime NOT NULL,
  `quien_recibe` varchar(100) NOT NULL,
  `observacion_entrega` varchar(100) DEFAULT NULL,
  `url_soporte_entrega` varchar(500) DEFAULT NULL,
  `estado` varchar(50) NOT NULL,
  `unidades_entregadas` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_despacho_dtl`),
  KEY `IXFK_despacho_dtl_despacho` (`id_despacho`),
  KEY `IXFK_despacho_dtl_pedido` (`id_pedido`),
  CONSTRAINT `FK_despacho_dtl_despacho` FOREIGN KEY (`id_despacho`) REFERENCES `despacho` (`id_despacho`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_despacho_dtl_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `despacho_dtl`
--

/*!40000 ALTER TABLE `despacho_dtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `despacho_dtl` ENABLE KEYS */;

--
-- Table structure for table `estado_pedido`
--

DROP TABLE IF EXISTS `estado_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_pedido` (
  `id_estado_pedido` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `notifica` int(11) NOT NULL DEFAULT 0,
  `visible_cte` int(11) NOT NULL DEFAULT 1,
  `color_texto` varchar(50) DEFAULT NULL,
  `color_estado` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_estado_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_pedido`
--

/*!40000 ALTER TABLE `estado_pedido` DISABLE KEYS */;
INSERT INTO `estado_pedido` VALUES (1,'Creado',0,1,'#000000','#6E6E6E',1),(2,'Tomando',0,1,'#000000','#00BFFF',1),(3,'Listo Para Alistamiento',0,1,'#000000','#00FF40',1),(4,'En Alistamiento',0,1,'#000000','#8000FF',1),(5,'Listo Para Despacho',0,1,'#000000','#0B6121',1),(6,'En Proceso de Despacho',0,1,'#000000','#FF8000',1),(7,'En Ruta de Entrega',0,1,'#000000','#FF8000',1),(8,'Entregado',0,1,'#000000','#2EFE2E',1),(9,'Devuelto',0,1,'#000000','#FF0040',1),(10,'Anulado',0,1,'#000000','#FF0040',1);
/*!40000 ALTER TABLE `estado_pedido` ENABLE KEYS */;

--
-- Table structure for table `historico_estados`
--

DROP TABLE IF EXISTS `historico_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historico_estados` (
  `id_historico` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL,
  `id_estado_pedido` int(11) NOT NULL,
  `usr_cambio` varchar(50) NOT NULL,
  `fecha_cambio` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `IXFK_hitorico_pedest_estado_pedido` (`id_estado_pedido`),
  KEY `IXFK_hitorico_pedido_estado_pedido` (`id_pedido`),
  CONSTRAINT `FK_hitorico_pedesta_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_hitorico_pedido_estado_pedido` FOREIGN KEY (`id_estado_pedido`) REFERENCES `estado_pedido` (`id_estado_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico_estados`
--

/*!40000 ALTER TABLE `historico_estados` DISABLE KEYS */;
/*!40000 ALTER TABLE `historico_estados` ENABLE KEYS */;

--
-- Table structure for table `medio_pago`
--

DROP TABLE IF EXISTS `medio_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medio_pago` (
  `id_medio_pago` int(11) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_medio_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medio_pago`
--

/*!40000 ALTER TABLE `medio_pago` DISABLE KEYS */;
INSERT INTO `medio_pago` VALUES (-1,'Pendiente',0),(1,'Efectivo',1),(2,'Credito',1),(3,'Consignación',1),(4,'Cheque',1),(5,'Tarjeta Crédito',1),(6,'Nequi',1),(7,'DaviPlata',1),(8,'Remision',1);
/*!40000 ALTER TABLE `medio_pago` ENABLE KEYS */;

--
-- Table structure for table `onboarding`
--

DROP TABLE IF EXISTS `onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onboarding` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `id_tipo_documento` int(11) NOT NULL,
  `documento` varchar(50) NOT NULL,
  `id_departamento` varchar(50) NOT NULL,
  `departamento` varchar(100) NOT NULL,
  `id_ciudad` varchar(50) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefonos` varchar(50) NOT NULL,
  `id_cliente` int(11) NOT NULL DEFAULT -1,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `fecha_gestion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_solicitud`),
  KEY `IXFK_onboarding_tipo_documento` (`id_tipo_documento`),
  CONSTRAINT `FK_onboarding_tipo_documento` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id_tipo_documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onboarding`
--

/*!40000 ALTER TABLE `onboarding` DISABLE KEYS */;
/*!40000 ALTER TABLE `onboarding` ENABLE KEYS */;

--
-- Table structure for table `pago`
--

DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago` (
  `id_pago` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_medio_pago` int(11) NOT NULL,
  `id_banco` int(11) NOT NULL DEFAULT -1,
  `valor_pago` int(11) NOT NULL,
  `fecha_pago` datetime NOT NULL,
  `id_pedido` bigint(20) NOT NULL,
  `referencia_pago` varchar(50) NOT NULL,
  `comentario_pago` varchar(100) DEFAULT NULL,
  `url_soporte_pago` varchar(200) DEFAULT NULL,
  `usr_creacion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pago`),
  KEY `IXFK_pago_banco` (`id_banco`),
  KEY `IXFK_pago_medio_pago` (`id_medio_pago`),
  KEY `IXFK_pago_pedido` (`id_pedido`),
  CONSTRAINT `FK_pago_banco` FOREIGN KEY (`id_banco`) REFERENCES `banco` (`id_banco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_pago_medio_pago` FOREIGN KEY (`id_medio_pago`) REFERENCES `medio_pago` (`id_medio_pago`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_pago_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago`
--

/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido` (
  `id_pedido` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `origen` varchar(50) NOT NULL COMMENT 'internet\r\n	mobile\r\n	store',
  `id_tipo_entrega` int(11) NOT NULL,
  `id_estado_pedido` int(11) NOT NULL,
  `id_dpto_entrega` varchar(50) NOT NULL,
  `dpto_entrega` varchar(100) NOT NULL,
  `id_ciudad_entrega` varchar(50) NOT NULL,
  `ciudad_entrega` varchar(100) NOT NULL,
  `direccion_entrega` varchar(100) NOT NULL,
  `contacto_entrega` varchar(100) DEFAULT NULL,
  `tel_contacto_entrega` varchar(50) DEFAULT NULL,
  `fecha_pactada_entrega` date DEFAULT NULL,
  `fecha_real_entrega` datetime DEFAULT NULL,
  `id_despacho` int(11) NOT NULL DEFAULT -1,
  `id_sucursal` int(11) NOT NULL,
  `sucursal_venta` varchar(100) NOT NULL,
  `observaciones_cliente` varchar(100) DEFAULT NULL,
  `observacion_interna` varchar(1000) DEFAULT NULL,
  `valor_total_pedido` int(11) NOT NULL DEFAULT 0,
  `descuento_total` int(11) NOT NULL DEFAULT 0 COMMENT 'valor del descuento del pedido.  No incluye impuestos',
  `usr_descuento` varchar(50) DEFAULT NULL,
  `fecha_descuento` datetime DEFAULT NULL,
  `valor_total_con_impuesto` int(11) NOT NULL DEFAULT 0,
  `valor_pagado` int(11) NOT NULL DEFAULT 0,
  `valor_adeudado` int(11) NOT NULL DEFAULT 0,
  `usr_creacion` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `integrado` int(11) NOT NULL DEFAULT 0,
  `fecha_integracion` datetime DEFAULT NULL,
  `url_soporte_entrega` varchar(500) NOT NULL DEFAULT '',
  `id_transferencia` bigint(20) NOT NULL DEFAULT -1,
  PRIMARY KEY (`id_pedido`),
  KEY `IXFK_pedido_cliente` (`id_cliente`),
  KEY `IXFK_pedido_estado_pedido` (`id_estado_pedido`),
  KEY `IXFK_pedido_tipo_entrega` (`id_tipo_entrega`),
  CONSTRAINT `FK_pedido_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_pedido_estado_pedido` FOREIGN KEY (`id_estado_pedido`) REFERENCES `estado_pedido` (`id_estado_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_pedido_tipo_entrega` FOREIGN KEY (`id_tipo_entrega`) REFERENCES `tipo_entrega` (`id_tipo_entrega`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;

--
-- Table structure for table `pedido_dtl`
--

DROP TABLE IF EXISTS `pedido_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido_dtl` (
  `id_pedido_dtl` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  `codigo_barras` varchar(50) NOT NULL,
  `nombre_producto` varchar(100) NOT NULL,
  `cantidad_pedido` int(11) NOT NULL,
  `precio_unitario` int(11) NOT NULL,
  `descuento_unitario` int(11) NOT NULL DEFAULT 0 COMMENT 'valor del descuento unitario.  No incluye impuestos',
  `precio_total` int(11) NOT NULL COMMENT 'precio unidades sin iva',
  `impuesto` int(11) NOT NULL,
  `valor_total` int(11) NOT NULL COMMENT 'valor unitario x cantidad + impuesto',
  `cantidad_alistada` int(11) NOT NULL DEFAULT 0,
  `usr_alistamiento` varchar(50) DEFAULT NULL,
  `url_imagen` varchar(500) NOT NULL DEFAULT '',
  `usr_creacion` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `integrado` int(11) NOT NULL DEFAULT 0,
  `fecha_integracion` datetime DEFAULT NULL,
  `id_transferencia_dtl` bigint(20) NOT NULL DEFAULT -1,
  PRIMARY KEY (`id_pedido_dtl`),
  KEY `IXFK_pedido_dtl_pedido` (`id_pedido`),
  CONSTRAINT `FK_pedido_dtl_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_dtl`
--

/*!40000 ALTER TABLE `pedido_dtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_dtl` ENABLE KEYS */;

--
-- Table structure for table `sucursal_cliente`
--

DROP TABLE IF EXISTS `sucursal_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursal_cliente` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `email_contacto` varchar(100) DEFAULT NULL,
  `tel_contacto` varchar(50) DEFAULT NULL,
  `id_departamento` varchar(50) DEFAULT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `id_ciudad` varchar(50) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`),
  KEY `IXFK_sucursal_cliente_cliente` (`id_cliente`),
  CONSTRAINT `FK_sucursal_cliente_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursal_cliente`
--

/*!40000 ALTER TABLE `sucursal_cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `sucursal_cliente` ENABLE KEYS */;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_documento` (
  `id_tipo_documento` int(11) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `sigla` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tipo_documento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_documento`
--

/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (1,'Cédula de Ciudadania','CC',1),(2,'Cédula de Extrangería','CE',1),(3,'Pasaporte','PTE',1);
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;

--
-- Table structure for table `tipo_entrega`
--

DROP TABLE IF EXISTS `tipo_entrega`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_entrega` (
  `id_tipo_entrega` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tipo_entrega`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_entrega`
--

/*!40000 ALTER TABLE `tipo_entrega` DISABLE KEYS */;
INSERT INTO `tipo_entrega` VALUES (1,'Pendiente Definir',1),(2,'Entrega Inmediata',1),(3,'Entrega a Domicilio',1);
/*!40000 ALTER TABLE `tipo_entrega` ENABLE KEYS */;

--
-- Dumping routines for database 'u290874471_db_pedidos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-27 20:08:58
