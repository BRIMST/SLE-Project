-- MariaDB dump 10.19  Distrib 10.6.14-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u290874471_db_seguridad
-- ------------------------------------------------------
-- Server version	10.6.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permiso` (
  `id_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `id_tipo_permiso` int(11) DEFAULT NULL,
  `id_interno` int(11) DEFAULT NULL,
  `url_ref_1` varchar(200) DEFAULT NULL,
  `url_ref_2` varchar(200) DEFAULT NULL,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_permiso`),
  UNIQUE KEY `uniq_nomb_permiso` (`nombre`),
  KEY `IXFK_permiso_tipo_permiso` (`id_tipo_permiso`),
  CONSTRAINT `FK_permiso_tipo_permiso` FOREIGN KEY (`id_tipo_permiso`) REFERENCES `tipo_permiso` (`id_tipo_permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso`
--

/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
INSERT INTO `permiso` VALUES (1,'SLE','Sistema Logistico Empresarial',1,-1,'--','--','developer',NULL,1),(2,'Usuarios','Usuarios',1,-1,'/usuarios','--','developer',NULL,1),(3,'Productos','Productos',2,-1,'/productos','--','developer',NULL,1),(4,'Proveedor','Crud de Proveedores',2,-1,'/proveedores','--','DEVELOPER','2022-06-07 02:01:15',1),(5,'Gestion Pedidos','Gestion de Pedidos',3,-1,'/pedidos','--','DEVELOPER','2022-06-07 02:01:35',1),(6,'Sucursales','Centros de Venta y Distribucion',2,-1,'/sucursales','--','SLE','2022-06-29 13:48:16',1),(7,'Transferencias','Gestion de Transferencias',2,-1,'/transferencias','--','SLE','2022-06-29 13:48:44',1),(8,'CM - Transferencias','Cargue masivo de transferencias de inventario',4,1,'/cargues/transferencias','/CargueMasivo/ProcesarCargueMasivoInventario/','developer','2022-08-03 23:39:56',1),(9,'CM - Productos','Cargue Masivo de Productos (Referencias)',4,2,'/cargues/productos','--','developer','2022-08-03 23:42:28',1),(10,'Alistamiento','Alistamiento de Mercancia',3,-1,'/alistamiento','--','developer','2022-08-03 23:42:28',1),(11,'Despacho','Despacho de Mercancia',3,-1,'/despachos','--','developer','2022-08-03 23:42:28',1),(12,'Clientes','Modulo de clientes',3,-1,'/clientes','--','developer',NULL,1),(13,'Pagos','Registro de pagos',3,-1,'/pagos','--','developer',NULL,1);
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `uniq_nomb_rol` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'Developer','Developer SLE',1),(2,'Administrador','Administrador SLE',1),(3,'Ventas','Vendedor MAJU',1),(4,'Alistamiento','Alistamiento MAJU',1),(5,'Cliente','Rol de Clientes Tienda',1),(6,'Despacho','Orquesta los despachos de MAJU',1),(7,'Conductor','Conductor de Entrega',1),(99,'API','Rol APIS',0);
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;

--
-- Table structure for table `rol_permiso`
--

DROP TABLE IF EXISTS `rol_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol_permiso` (
  `id_rol` int(11) NOT NULL,
  `id_permiso` int(11) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_rol`,`id_permiso`),
  KEY `IXFK_rol_permiso_permiso` (`id_permiso`),
  KEY `IXFK_rol_permiso_rol` (`id_rol`),
  CONSTRAINT `FK_rol_permiso_permiso` FOREIGN KEY (`id_permiso`) REFERENCES `permiso` (`id_permiso`),
  CONSTRAINT `FK_rol_permiso_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_permiso`
--

/*!40000 ALTER TABLE `rol_permiso` DISABLE KEYS */;
INSERT INTO `rol_permiso` VALUES (1,1,1),(1,2,1),(1,3,1),(1,4,1),(1,5,1),(1,6,1),(1,7,1),(1,8,1),(1,9,1),(1,10,1),(1,11,1),(1,12,1),(1,13,1),(2,2,1),(2,3,1),(2,4,1),(2,5,1),(2,6,1),(2,7,1),(2,8,1),(2,9,1),(2,10,1),(2,11,1),(2,12,1),(2,13,1),(3,10,1),(3,11,1),(4,10,1),(6,11,1),(7,11,1);
/*!40000 ALTER TABLE `rol_permiso` ENABLE KEYS */;

--
-- Table structure for table `tipo_permiso`
--

DROP TABLE IF EXISTS `tipo_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_permiso` (
  `id_tipo_permiso` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `endpoint` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_permiso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_permiso`
--

/*!40000 ALTER TABLE `tipo_permiso` DISABLE KEYS */;
INSERT INTO `tipo_permiso` VALUES (1,'Seguridad','./assets/media/icons/duotune/technology/teh004.svg'),(2,'Inventario','./assets/media/icons/duotune/ecommerce/ecm001.svg'),(3,'Pedidos','./assets/media/icons/duotune/general/gen022.svg'),(4,'Cargues Masivos','./assets/media/icons/duotune/abstract/abs029.svg');
/*!40000 ALTER TABLE `tipo_permiso` ENABLE KEYS */;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id_token` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `tokenhash` varchar(1000) NOT NULL,
  `tokensalt` varchar(100) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `fecha_expiracion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  KEY `IXFK_token_usuario` (`id_usuario`),
  CONSTRAINT `FK_token_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (12,1,'2MMfoqp9W/0kgxDK2lWkDANMg1pq9amxv3KuH9PcnJ0=','hRp2JRpATSlzxC8Wt6uJMZRPQ1YFokAgW+PVU2Tvvf4=','2023-07-18 02:02:30','2023-08-17 02:02:30'),(22,2,'1umaA1n2DOigv9pUmwss0wz71dJhKqC+dV7svrMr+fo=','zo6sw/19+r1bxKoU0/D0L14Y6eRVJN/i8U/H/fO7ZM8=','2023-09-07 18:57:40','2023-10-07 18:57:40');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;

--
-- Table structure for table `token_hist`
--

DROP TABLE IF EXISTS `token_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token_hist` (
  `idToken` bigint(20) NOT NULL AUTO_INCREMENT,
  `idusuario` int(11) NOT NULL DEFAULT -1,
  `nombre_usuario` varchar(50) NOT NULL,
  `id_permiso` int(11) NOT NULL DEFAULT -1,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`idToken`),
  KEY `ix_token_hist_nomb_usr` (`nombre_usuario`),
  KEY `ix_token_hist_fech_log` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_hist`
--

/*!40000 ALTER TABLE `token_hist` DISABLE KEYS */;
INSERT INTO `token_hist` VALUES (1,1,'DEVELOPER',1,'2023-07-16 13:04:05'),(2,1,'DEVELOPER',2,'2023-07-16 13:04:18'),(3,1,'DEVELOPER',3,'2023-07-16 13:04:22'),(4,1,'DEVELOPER',4,'2023-07-16 13:04:26'),(5,1,'DEVELOPER',1,'2023-07-16 13:04:40'),(6,1,'DEVELOPER',2,'2023-07-16 13:04:44'),(7,1,'DEVELOPER',3,'2023-07-16 13:04:54'),(8,1,'DEVELOPER',1,'2023-07-16 21:47:22'),(9,1,'DEVELOPER',2,'2023-07-16 21:47:30'),(10,1,'DEVELOPER',3,'2023-07-16 21:47:41'),(11,1,'DEVELOPER',4,'2023-07-16 21:47:49'),(12,1,'DEVELOPER',6,'2023-07-16 21:47:53'),(13,1,'DEVELOPER',1,'2023-07-17 19:57:59'),(14,1,'DEVELOPER',1,'2023-07-17 19:58:40'),(15,1,'DEVELOPER',1,'2023-07-17 19:59:01'),(16,1,'DEVELOPER',2,'2023-07-17 20:02:10'),(17,1,'DEVELOPER',6,'2023-07-17 20:03:00'),(18,-1,'',6,'2023-07-17 20:03:39'),(19,-1,'',6,'2023-07-17 20:05:01'),(20,-1,'',6,'2023-07-17 20:06:51'),(21,-1,'',6,'2023-07-17 20:08:05'),(22,-1,'',2,'2023-07-17 20:08:25'),(23,-1,'',2,'2023-07-17 20:08:50'),(24,-1,'',2,'2023-07-17 20:08:59'),(25,-1,'',6,'2023-07-17 20:10:49'),(26,-1,'',6,'2023-07-17 20:11:21'),(27,-1,'',2,'2023-07-17 20:23:12'),(28,-1,'',2,'2023-07-17 20:24:09'),(29,2,'ADMINISTRADOR',1,'2023-07-17 20:24:27'),(30,2,'ADMINISTRADOR',3,'2023-07-17 20:25:47'),(31,1,'DEVELOPER',1,'2023-07-17 20:29:15'),(32,1,'DEVELOPER',1,'2023-07-17 20:29:57'),(33,1,'DEVELOPER',2,'2023-07-17 20:30:10'),(34,1,'DEVELOPER',1,'2023-07-17 21:02:33'),(35,1,'DEVELOPER',2,'2023-07-17 21:02:45'),(36,1,'DEVELOPER',2,'2023-07-17 21:03:32'),(37,-1,'',2,'2023-07-17 21:03:35'),(38,-1,'',6,'2023-07-17 21:08:45'),(39,-1,'',6,'2023-07-17 21:14:26'),(40,2,'ADMINISTRADOR',1,'2023-07-19 08:57:42'),(41,2,'ADMINISTRADOR',2,'2023-07-19 12:18:17'),(42,2,'ADMINISTRADOR',2,'2023-07-19 12:19:52'),(43,2,'ADMINISTRADOR',2,'2023-07-19 12:20:28'),(44,2,'ADMINISTRADOR',2,'2023-07-19 12:20:55'),(45,2,'ADMINISTRADOR',3,'2023-07-19 12:24:29'),(46,2,'ADMINISTRADOR',1,'2023-08-16 09:49:58'),(47,2,'ADMINISTRADOR',2,'2023-08-16 09:50:08'),(48,2,'ADMINISTRADOR',2,'2023-08-16 09:51:07'),(49,2,'ADMINISTRADOR',2,'2023-08-16 09:51:17'),(50,2,'ADMINISTRADOR',2,'2023-08-16 09:51:26'),(51,2,'ADMINISTRADOR',3,'2023-08-16 09:52:28'),(52,2,'ADMINISTRADOR',4,'2023-08-16 09:52:40'),(53,2,'ADMINISTRADOR',6,'2023-08-16 09:52:43'),(54,2,'ADMINISTRADOR',6,'2023-08-16 09:53:10'),(55,2,'ADMINISTRADOR',6,'2023-08-16 09:55:06'),(56,-1,'',6,'2023-08-18 10:23:58'),(57,2,'ADMINISTRADOR',1,'2023-09-07 13:57:53'),(58,2,'ADMINISTRADOR',2,'2023-09-07 13:57:59'),(59,2,'ADMINISTRADOR',3,'2023-09-07 13:58:31'),(60,2,'ADMINISTRADOR',4,'2023-09-07 13:58:37'),(61,2,'ADMINISTRADOR',2,'2023-09-07 14:01:38'),(62,2,'ADMINISTRADOR',3,'2023-09-07 14:03:17'),(63,2,'ADMINISTRADOR',6,'2023-09-07 14:03:24'),(64,2,'ADMINISTRADOR',2,'2023-09-07 14:04:03');
/*!40000 ALTER TABLE `token_hist` ENABLE KEYS */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(50) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `id_rol` int(11) DEFAULT NULL,
  `id_sucursal` int(11) NOT NULL DEFAULT -1,
  `sucursal` varchar(50) DEFAULT 'web',
  `clave` varchar(1000) NOT NULL,
  `clave_salt` varchar(100) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `documento` varchar(50) DEFAULT NULL,
  `usr_creacion` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `usr_modificacion` varchar(50) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `referencia_imagen` varchar(100) DEFAULT NULL,
  `url_imagen` varchar(300) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `uniq_usuario` (`nombre_usuario`),
  KEY `IXFK_usuario_rol` (`id_rol`),
  CONSTRAINT `FK_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'developer',-1,1,-1,'web','WZldytZQUkKKtGs85DFajqMrIL6WXSDPp4cJ23nJOn0=','VD+FwwV9sefrLkQJzmLiJ+qAL6Q/cwUNv0c04SDlEoI=','Developer','developer@sle.com',NULL,NULL,NULL,'developer','2023-07-17 21:03:30','sle/perfil/1sbev0ykjlyi','https://firebasestorage.googleapis.com/v0/b/sle-ms.appspot.com/o/sle%2Fperfil%2F1sbev0ykjlyi?alt=media&token=e014d4e5-8a87-437d-8263-0812d1b126e4',1),(2,'administrador',2,2,-1,'web','fpHeMIm1uuEZNNje7/Qcc9IIIRQGJUmFIhBQM+Mzi2E=','ZFnhTsVTLb5LgceAk/f6kNRDG8WKY6JU9/5P0nTM0M8=','Frank Toro','kagure@gmail.com',NULL,NULL,NULL,'administrador','2023-08-16 09:51:24','','',1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

--
-- Dumping routines for database 'u290874471_db_seguridad'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-27 20:09:02
